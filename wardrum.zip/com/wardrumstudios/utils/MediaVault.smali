.class public Lcom/wardrumstudios/utils/MediaVault;
.super Ljava/lang/Object;
.source "MediaVault.java"


# instance fields
.field private secret:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .registers 2
    .param p1, "secret"  # Ljava/lang/String;

    .prologue
    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 11
    iput-object p1, p0, Lcom/wardrumstudios/utils/MediaVault;->secret:Ljava/lang/String;

    .line 12
    return-void
.end method

.method private getMD5Hash(Ljava/lang/String;)Ljava/lang/String;
    .registers 5
    .param p1, "hashParams"  # Ljava/lang/String;

    .prologue
    .line 55
    :try_start_0
    const-string v2, "MD5"

    invoke-static {v2}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v1

    .line 56
    .local v1, "md":Ljava/security/MessageDigest;
    invoke-virtual {p1}, Ljava/lang/String;->getBytes()[B

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/security/MessageDigest;->update([B)V

    .line 58
    invoke-virtual {v1}, Ljava/security/MessageDigest;->digest()[B

    move-result-object v2

    invoke-direct {p0, v2}, Lcom/wardrumstudios/utils/MediaVault;->toHexString([B)Ljava/lang/String;
    :try_end_14
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_0 .. :try_end_14} :catch_16

    move-result-object v2

    .line 60
    .end local v1  # "md":Ljava/security/MessageDigest;
    :goto_15
    return-object v2

    .line 59
    :catch_16
    move-exception v0

    .line 60
    .local v0, "ex":Ljava/security/NoSuchAlgorithmException;
    const-string v2, ""

    goto :goto_15
.end method

.method private toHexString([B)Ljava/lang/String;
    .registers 7
    .param p1, "b"  # [B

    .prologue
    const/16 v4, 0x10

    .line 65
    new-instance v1, Ljava/lang/StringBuilder;

    array-length v2, p1

    mul-int/lit8 v2, v2, 0x2

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 67
    .local v1, "sb":Ljava/lang/StringBuilder;
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_b
    array-length v2, p1

    if-ge v0, v2, :cond_28

    .line 68
    aget-byte v2, p1, v0

    and-int/lit16 v2, v2, 0xff

    if-ge v2, v4, :cond_19

    .line 69
    const-string v2, "0"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 72
    :cond_19
    aget-byte v2, p1, v0

    and-int/lit16 v2, v2, 0xff

    int-to-long v2, v2

    invoke-static {v2, v3, v4}, Ljava/lang/Long;->toString(JI)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 67
    add-int/lit8 v0, v0, 0x1

    goto :goto_b

    .line 74
    :cond_28
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    return-object v2
.end method


# virtual methods
.method public compute()Ljava/lang/String;
    .registers 2

    .prologue
    .line 15
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcom/wardrumstudios/utils/MediaVault;->compute(Lcom/wardrumstudios/utils/MediaVaultRequest;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public compute(Lcom/wardrumstudios/utils/MediaVaultRequest;)Ljava/lang/String;
    .registers 9
    .param p1, "options"  # Lcom/wardrumstudios/utils/MediaVaultRequest;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    .prologue
    const/4 v6, -0x1

    .line 19
    if-nez p1, :cond_b

    .line 20
    new-instance v4, Ljava/lang/IllegalArgumentException;

    const-string v5, "Invalid \'options\' parameter."

    invoke-direct {v4, v5}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v4

    .line 21
    :cond_b
    invoke-virtual {p1}, Lcom/wardrumstudios/utils/MediaVaultRequest;->getMediaURL()Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_1b

    invoke-virtual {p1}, Lcom/wardrumstudios/utils/MediaVaultRequest;->getMediaURL()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v4

    if-nez v4, :cond_23

    .line 22
    :cond_1b
    new-instance v4, Ljava/lang/IllegalArgumentException;

    const-string v5, "options.getMediaURL() is required."

    invoke-direct {v4, v5}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v4

    .line 23
    :cond_23
    iget-object v4, p0, Lcom/wardrumstudios/utils/MediaVault;->secret:Ljava/lang/String;

    if-eqz v4, :cond_2f

    iget-object v4, p0, Lcom/wardrumstudios/utils/MediaVault;->secret:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v4

    if-nez v4, :cond_37

    .line 24
    :cond_2f
    new-instance v4, Ljava/lang/IllegalArgumentException;

    const-string v5, "MediaVault.getSecret() is null."

    invoke-direct {v4, v5}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v4

    .line 27
    :cond_37
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lcom/wardrumstudios/utils/MediaVaultRequest;->getMediaURL()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 28
    .local v2, "result":Ljava/lang/StringBuilder;
    const-string v3, ""

    .line 29
    .local v3, "urlParams":Ljava/lang/String;
    const-string v1, ""

    .line 31
    .local v1, "hashParams":Ljava/lang/String;
    if-eqz p1, :cond_4e

    .line 32
    invoke-virtual {p1}, Lcom/wardrumstudios/utils/MediaVaultRequest;->getURLParamers()Ljava/lang/String;

    move-result-object v3

    .line 33
    invoke-virtual {p1}, Lcom/wardrumstudios/utils/MediaVaultRequest;->getHashParameters()Ljava/lang/String;

    move-result-object v1

    .line 36
    :cond_4e
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v4

    if-lez v4, :cond_72

    .line 37
    const-string v4, "?"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->indexOf(Ljava/lang/String;)I

    move-result v4

    if-le v4, v6, :cond_b0

    .line 38
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "&"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 43
    :cond_72
    :goto_72
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v5, p0, Lcom/wardrumstudios/utils/MediaVault;->secret:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {p0, v4}, Lcom/wardrumstudios/utils/MediaVault;->getMD5Hash(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 45
    .local v0, "hash":Ljava/lang/String;
    const-string v4, "?"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->indexOf(Ljava/lang/String;)I

    move-result v4

    if-le v4, v6, :cond_c7

    .line 46
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "&h="

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 50
    :goto_ab
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    return-object v4

    .line 40
    .end local v0  # "hash":Ljava/lang/String;
    :cond_b0
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "?"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_72

    .line 48
    .restart local v0  # "hash":Ljava/lang/String;
    :cond_c7
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "?h="

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_ab
.end method

.method public getSecret()Ljava/lang/String;
    .registers 2

    .prologue
    .line 81
    iget-object v0, p0, Lcom/wardrumstudios/utils/MediaVault;->secret:Ljava/lang/String;

    return-object v0
.end method

.method public setSecret(Ljava/lang/String;)V
    .registers 2
    .param p1, "secret"  # Ljava/lang/String;

    .prologue
    .line 89
    iput-object p1, p0, Lcom/wardrumstudios/utils/MediaVault;->secret:Ljava/lang/String;

    .line 90
    return-void
.end method
