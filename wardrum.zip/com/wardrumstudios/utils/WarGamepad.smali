.class public Lcom/wardrumstudios/utils/WarGamepad;
.super Lcom/wardrumstudios/utils/WarBilling;
.source "WarGamepad.java"

# interfaces
.implements Lcom/bda/controller/ControllerListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/wardrumstudios/utils/WarGamepad$GamePad;
    }
.end annotation


# static fields
.field private static final COMMAND_DOWN:I = 0x2

.field private static final COMMAND_FIRE:I = 0x10

.field private static final COMMAND_LEFT:I = 0x8

.field private static final COMMAND_RIGHT:I = 0x4

.field private static final COMMAND_STATUS:I = 0x40

.field private static final COMMAND_STOP:I = 0x20

.field private static final COMMAND_UP:I = 0x1

.field static MAX_GAME_PADS:I = 0x0

.field private static final OSGT_60beat:I = 0x2

.field private static final OSGT_AmazonGamepad:I = 0xc

.field private static final OSGT_AmazonRemote:I = 0xb

.field private static final OSGT_AndroidTV:I = 0xd

.field private static final OSGT_Gamestop:I = 0x3

.field private static final OSGT_Generic:I = 0x5

.field private static final OSGT_IOSExtended:I = 0x9

.field private static final OSGT_IOSSimple:I = 0xa

.field private static final OSGT_Moga:I = 0x4

.field private static final OSGT_MogaPro:I = 0x7

.field private static final OSGT_Nyko:I = 0x6

.field private static final OSGT_PS3:I = 0x8

.field private static final OSGT_Xbox360:I = 0x0

.field private static final OSGT_XperiaPlay:I = 0x1

.field private static final OSX360_A:I = 0x1

.field private static final OSX360_AXIS_L2:I = 0x4

.field private static final OSX360_AXIS_R2:I = 0x5

.field private static final OSX360_AXIS_X1:I = 0x0

.field private static final OSX360_AXIS_X2:I = 0x2

.field private static final OSX360_AXIS_Y1:I = 0x1

.field private static final OSX360_AXIS_Y2:I = 0x3

.field private static final OSX360_B:I = 0x2

.field private static final OSX360_BACK:I = 0x20

.field private static final OSX360_DPADDOWN:I = 0x200

.field private static final OSX360_DPADLEFT:I = 0x400

.field private static final OSX360_DPADRIGHT:I = 0x800

.field private static final OSX360_DPADUP:I = 0x100

.field private static final OSX360_L1:I = 0x40

.field private static final OSX360_L3:I = 0x1000

.field private static final OSX360_R1:I = 0x80

.field private static final OSX360_R3:I = 0x2000

.field private static final OSX360_START:I = 0x10

.field private static final OSX360_X:I = 0x4

.field private static final OSX360_Y:I = 0x8

.field private static final OSXP_BACK:I = 0x4000

.field private static final OSXP_GP_MENU:I = 0x8000

.field private static final OSXP_MENU:I = 0x1000

.field private static final OSXP_SEARCH:I = 0x2000

.field private static final TAG:Ljava/lang/String; = "WarGamepad"


# instance fields
.field public GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

.field protected IsAndroidTV:Z

.field mogaController:Lcom/bda/controller/Controller;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .prologue
    .line 156
    const/4 v0, 0x4

    sput v0, Lcom/wardrumstudios/utils/WarGamepad;->MAX_GAME_PADS:I

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    .prologue
    .line 33
    invoke-direct {p0}, Lcom/wardrumstudios/utils/WarBilling;-><init>()V

    .line 36
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/wardrumstudios/utils/WarGamepad;->IsAndroidTV:Z

    .line 95
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/wardrumstudios/utils/WarGamepad;->mogaController:Lcom/bda/controller/Controller;

    return-void
.end method

.method private ClearBadJoystickAxis(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)V
    .registers 9
    .param p1, "myGamepad"  # Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    .prologue
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/high16 v2, -0x40800000  # -1.0f

    .line 527
    iget-object v0, p1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    aget v0, v0, v4

    cmpl-float v0, v0, v2

    if-nez v0, :cond_42

    iget-object v0, p1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    aget v0, v0, v5

    cmpl-float v0, v0, v2

    if-nez v0, :cond_42

    iget-object v0, p1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    aget v0, v0, v6

    cmpl-float v0, v0, v2

    if-nez v0, :cond_42

    iget-object v0, p1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    const/4 v1, 0x3

    aget v0, v0, v1

    cmpl-float v0, v0, v2

    if-nez v0, :cond_42

    .line 529
    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v1, "Clearing Bad Joystick Axis"

    invoke-virtual {v0, v1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    .line 531
    iget-object v0, p1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    aput v3, v0, v4

    .line 532
    iget-object v0, p1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    aput v3, v0, v5

    .line 533
    iget-object v0, p1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    aput v3, v0, v6

    .line 534
    iget-object v0, p1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    const/4 v1, 0x3

    aput v3, v0, v1

    .line 535
    const/4 v0, -0x1

    iput v0, p1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    .line 537
    :cond_42
    return-void
.end method

.method private static IsValidAxis(Landroid/view/MotionEvent;Landroid/view/InputDevice;I)Z
    .registers 5
    .param p0, "event"  # Landroid/view/MotionEvent;
    .param p1, "device"  # Landroid/view/InputDevice;
    .param p2, "axis"  # I

    .prologue
    .line 623
    invoke-virtual {p0}, Landroid/view/MotionEvent;->getSource()I

    move-result v1

    invoke-virtual {p1, p2, v1}, Landroid/view/InputDevice;->getMotionRange(II)Landroid/view/InputDevice$MotionRange;

    move-result-object v0

    .line 624
    .local v0, "range":Landroid/view/InputDevice$MotionRange;
    if-eqz v0, :cond_c

    const/4 v1, 0x1

    :goto_b
    return v1

    :cond_c
    const/4 v1, 0x0

    goto :goto_b
.end method

.method private static getCenteredAxis(Landroid/view/MotionEvent;Landroid/view/InputDevice;II)F
    .registers 8
    .param p0, "event"  # Landroid/view/MotionEvent;
    .param p1, "device"  # Landroid/view/InputDevice;
    .param p2, "axis"  # I
    .param p3, "historyPos"  # I

    .prologue
    .line 628
    invoke-virtual {p0}, Landroid/view/MotionEvent;->getSource()I

    move-result v3

    invoke-virtual {p1, p2, v3}, Landroid/view/InputDevice;->getMotionRange(II)Landroid/view/InputDevice$MotionRange;

    move-result-object v1

    .line 629
    .local v1, "range":Landroid/view/InputDevice$MotionRange;
    if-eqz v1, :cond_22

    .line 630
    invoke-virtual {v1}, Landroid/view/InputDevice$MotionRange;->getFlat()F

    move-result v0

    .line 631
    .local v0, "flat":F
    if-gez p3, :cond_1d

    invoke-virtual {p0, p2}, Landroid/view/MotionEvent;->getAxisValue(I)F

    move-result v2

    .line 634
    .local v2, "value":F
    :goto_14
    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    move-result v3

    cmpl-float v3, v3, v0

    if-lez v3, :cond_22

    .line 638
    .end local v0  # "flat":F
    .end local v2  # "value":F
    :goto_1c
    return v2

    .line 632
    .restart local v0  # "flat":F
    :cond_1d
    invoke-virtual {p0, p2, p3}, Landroid/view/MotionEvent;->getHistoricalAxisValue(II)F

    move-result v2

    goto :goto_14

    .line 638
    .end local v0  # "flat":F
    :cond_22
    const/4 v2, 0x0

    goto :goto_1c
.end method

.method private processJoystickInput(Landroid/view/MotionEvent;I)V
    .registers 15
    .param p1, "event"  # Landroid/view/MotionEvent;
    .param p2, "historyPos"  # I

    .prologue
    .line 540
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getDeviceId()I

    move-result v7

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getSource()I

    move-result v8

    invoke-virtual {p0, v7, v8}, Lcom/wardrumstudios/utils/WarGamepad;->GetDeviceIndex(II)I

    move-result v2

    .line 541
    .local v2, "index":I
    const/4 v7, -0x1

    if-ne v2, v7, :cond_3a

    .line 542
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getDevice()Landroid/view/InputDevice;

    move-result-object v7

    if-eqz v7, :cond_38

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getDevice()Landroid/view/InputDevice;

    move-result-object v7

    invoke-virtual {v7}, Landroid/view/InputDevice;->getSources()I

    move-result v4

    .line 543
    .local v4, "source":I
    :goto_1d
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getDeviceId()I

    move-result v7

    invoke-virtual {p0, v7, v4}, Lcom/wardrumstudios/utils/WarGamepad;->GetFreeIndex(II)I

    move-result v2

    .line 544
    const/4 v7, -0x1

    if-ne v2, v7, :cond_3a

    .line 545
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getSource()I

    move-result v7

    and-int/lit8 v7, v7, 0x10

    if-eqz v7, :cond_37

    .line 546
    sget-object v7, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v8, "********************ERROR********* cannot assign controller"

    invoke-virtual {v7, v8}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    .line 620
    .end local v4  # "source":I
    :cond_37
    :goto_37
    return-void

    .line 542
    :cond_38
    const/4 v4, 0x0

    goto :goto_1d

    .line 551
    :cond_3a
    iget-object v7, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v3, v7, v2

    .line 557
    .local v3, "myGamePad":Lcom/wardrumstudios/utils/WarGamepad$GamePad;
    iget-object v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    const/4 v8, 0x0

    invoke-static {v3}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v9

    const/4 v10, 0x0

    invoke-static {p1, v9, v10, p2}, Lcom/wardrumstudios/utils/WarGamepad;->getCenteredAxis(Landroid/view/MotionEvent;Landroid/view/InputDevice;II)F

    move-result v9

    aput v9, v7, v8

    .line 558
    iget-object v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    const/4 v8, 0x1

    invoke-static {v3}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v9

    const/4 v10, 0x1

    invoke-static {p1, v9, v10, p2}, Lcom/wardrumstudios/utils/WarGamepad;->getCenteredAxis(Landroid/view/MotionEvent;Landroid/view/InputDevice;II)F

    move-result v9

    aput v9, v7, v8

    .line 559
    iget-object v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    const/4 v8, 0x2

    invoke-static {v3}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v9

    const/16 v10, 0xb

    invoke-static {p1, v9, v10, p2}, Lcom/wardrumstudios/utils/WarGamepad;->getCenteredAxis(Landroid/view/MotionEvent;Landroid/view/InputDevice;II)F

    move-result v9

    aput v9, v7, v8

    .line 560
    iget-object v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    const/4 v8, 0x3

    invoke-static {v3}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v9

    const/16 v10, 0xe

    invoke-static {p1, v9, v10, p2}, Lcom/wardrumstudios/utils/WarGamepad;->getCenteredAxis(Landroid/view/MotionEvent;Landroid/view/InputDevice;II)F

    move-result v9

    aput v9, v7, v8

    .line 562
    invoke-static {v3}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v7

    const/16 v8, 0x11

    invoke-static {p1, v7, v8}, Lcom/wardrumstudios/utils/WarGamepad;->IsValidAxis(Landroid/view/MotionEvent;Landroid/view/InputDevice;I)Z

    move-result v7

    if-nez v7, :cond_90

    invoke-static {v3}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v7

    const/16 v8, 0x17

    invoke-static {p1, v7, v8}, Lcom/wardrumstudios/utils/WarGamepad;->IsValidAxis(Landroid/view/MotionEvent;Landroid/view/InputDevice;I)Z

    move-result v7

    if-eqz v7, :cond_b3

    .line 563
    :cond_90
    invoke-static {v3}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v7

    const/16 v8, 0x11

    invoke-static {p1, v7, v8, p2}, Lcom/wardrumstudios/utils/WarGamepad;->getCenteredAxis(Landroid/view/MotionEvent;Landroid/view/InputDevice;II)F

    move-result v5

    .line 564
    .local v5, "valL2":F
    const/4 v7, 0x0

    cmpl-float v7, v5, v7

    if-nez v7, :cond_ae

    iget-object v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    const/4 v8, 0x4

    invoke-static {v3}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v9

    const/16 v10, 0x17

    invoke-static {p1, v9, v10, p2}, Lcom/wardrumstudios/utils/WarGamepad;->getCenteredAxis(Landroid/view/MotionEvent;Landroid/view/InputDevice;II)F

    move-result v5

    .end local v5  # "valL2":F
    aput v5, v7, v8

    .line 565
    .restart local v5  # "valL2":F
    :cond_ae
    iget-object v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    const/4 v8, 0x4

    aput v5, v7, v8

    .line 567
    .end local v5  # "valL2":F
    :cond_b3
    invoke-static {v3}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v7

    const/16 v8, 0x12

    invoke-static {p1, v7, v8}, Lcom/wardrumstudios/utils/WarGamepad;->IsValidAxis(Landroid/view/MotionEvent;Landroid/view/InputDevice;I)Z

    move-result v7

    if-nez v7, :cond_cb

    invoke-static {v3}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v7

    const/16 v8, 0x16

    invoke-static {p1, v7, v8}, Lcom/wardrumstudios/utils/WarGamepad;->IsValidAxis(Landroid/view/MotionEvent;Landroid/view/InputDevice;I)Z

    move-result v7

    if-eqz v7, :cond_ee

    .line 568
    :cond_cb
    invoke-static {v3}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v7

    const/16 v8, 0x12

    invoke-static {p1, v7, v8, p2}, Lcom/wardrumstudios/utils/WarGamepad;->getCenteredAxis(Landroid/view/MotionEvent;Landroid/view/InputDevice;II)F

    move-result v6

    .line 569
    .local v6, "valR2":F
    const/4 v7, 0x0

    cmpl-float v7, v6, v7

    if-nez v7, :cond_e9

    iget-object v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    const/4 v8, 0x5

    invoke-static {v3}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v9

    const/16 v10, 0x16

    invoke-static {p1, v9, v10, p2}, Lcom/wardrumstudios/utils/WarGamepad;->getCenteredAxis(Landroid/view/MotionEvent;Landroid/view/InputDevice;II)F

    move-result v6

    .end local v6  # "valR2":F
    aput v6, v7, v8

    .line 570
    .restart local v6  # "valR2":F
    :cond_e9
    iget-object v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    const/4 v8, 0x5

    aput v6, v7, v8

    .line 575
    .end local v6  # "valR2":F
    :cond_ee
    iget v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    const/4 v8, 0x6

    if-eq v7, v8, :cond_37

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v8

    iget-wide v10, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->lastConnect:J

    sub-long/2addr v8, v10

    const-wide/16 v10, 0x3e8

    cmp-long v7, v8, v10

    if-lez v7, :cond_37

    .line 576
    invoke-static {v3}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v7

    const/16 v8, 0xf

    invoke-static {p1, v7, v8, p2}, Lcom/wardrumstudios/utils/WarGamepad;->getCenteredAxis(Landroid/view/MotionEvent;Landroid/view/InputDevice;II)F

    move-result v0

    .line 577
    .local v0, "DPAD_X":F
    invoke-static {v3}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v7

    const/16 v8, 0x10

    invoke-static {p1, v7, v8, p2}, Lcom/wardrumstudios/utils/WarGamepad;->getCenteredAxis(Landroid/view/MotionEvent;Landroid/view/InputDevice;II)F

    move-result v1

    .line 579
    .local v1, "DPAD_Y":F
    iget-boolean v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->mightBeNyko:Z

    if-eqz v7, :cond_1d1

    .line 580
    iget-object v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    const/4 v8, 0x0

    aget v7, v7, v8

    const/high16 v8, 0x3f400000  # 0.75f

    cmpl-float v7, v7, v8

    if-lez v7, :cond_12f

    const/high16 v7, 0x3f400000  # 0.75f

    cmpl-float v7, v0, v7

    if-lez v7, :cond_12f

    .line 581
    iget v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->NykoCheckHacks:I

    or-int/lit8 v7, v7, 0x1

    iput v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->NykoCheckHacks:I

    .line 582
    :cond_12f
    iget-object v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    const/4 v8, 0x0

    aget v7, v7, v8

    const/high16 v8, -0x40c00000  # -0.75f

    cmpg-float v7, v7, v8

    if-gez v7, :cond_146

    const/high16 v7, -0x40c00000  # -0.75f

    cmpg-float v7, v0, v7

    if-gez v7, :cond_146

    .line 583
    iget v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->NykoCheckHacks:I

    or-int/lit8 v7, v7, 0x2

    iput v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->NykoCheckHacks:I

    .line 584
    :cond_146
    iget-object v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    const/4 v8, 0x1

    aget v7, v7, v8

    const/high16 v8, 0x3f400000  # 0.75f

    cmpl-float v7, v7, v8

    if-lez v7, :cond_15d

    const/high16 v7, 0x3f400000  # 0.75f

    cmpl-float v7, v1, v7

    if-lez v7, :cond_15d

    .line 585
    iget v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->NykoCheckHacks:I

    or-int/lit8 v7, v7, 0x4

    iput v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->NykoCheckHacks:I

    .line 586
    :cond_15d
    iget-object v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    const/4 v8, 0x1

    aget v7, v7, v8

    const v8, -0x40cccccd  # -0.7f

    cmpg-float v7, v7, v8

    if-gez v7, :cond_175

    const/high16 v7, 0x3f400000  # 0.75f

    cmpg-float v7, v1, v7

    if-gez v7, :cond_175

    .line 587
    iget v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->NykoCheckHacks:I

    or-int/lit8 v7, v7, 0x8

    iput v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->NykoCheckHacks:I

    .line 589
    :cond_175
    iget-object v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    const/4 v8, 0x0

    aget v7, v7, v8

    const/high16 v8, 0x3f400000  # 0.75f

    cmpl-float v7, v7, v8

    if-lez v7, :cond_188

    const/4 v7, 0x0

    cmpl-float v7, v0, v7

    if-nez v7, :cond_188

    .line 590
    const/4 v7, 0x0

    iput-boolean v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->mightBeNyko:Z

    .line 591
    :cond_188
    iget-object v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    const/4 v8, 0x0

    aget v7, v7, v8

    const/high16 v8, -0x40c00000  # -0.75f

    cmpg-float v7, v7, v8

    if-gez v7, :cond_19b

    const/4 v7, 0x0

    cmpl-float v7, v0, v7

    if-nez v7, :cond_19b

    .line 592
    const/4 v7, 0x0

    iput-boolean v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->mightBeNyko:Z

    .line 593
    :cond_19b
    iget-object v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    const/4 v8, 0x1

    aget v7, v7, v8

    const/high16 v8, 0x3f400000  # 0.75f

    cmpl-float v7, v7, v8

    if-lez v7, :cond_1ae

    const/4 v7, 0x0

    cmpl-float v7, v1, v7

    if-nez v7, :cond_1ae

    .line 594
    const/4 v7, 0x0

    iput-boolean v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->mightBeNyko:Z

    .line 595
    :cond_1ae
    iget-object v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    const/4 v8, 0x1

    aget v7, v7, v8

    const/high16 v8, -0x40c00000  # -0.75f

    cmpg-float v7, v7, v8

    if-gez v7, :cond_1c1

    const/4 v7, 0x0

    cmpl-float v7, v1, v7

    if-nez v7, :cond_1c1

    .line 596
    const/4 v7, 0x0

    iput-boolean v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->mightBeNyko:Z

    .line 598
    :cond_1c1
    iget v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->NykoCheckHacks:I

    const/16 v8, 0xf

    if-ne v7, v8, :cond_1d1

    .line 599
    const/4 v7, 0x6

    iput v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    .line 600
    sget-object v7, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v8, "detecting NYKO controller"

    invoke-virtual {v7, v8}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    .line 604
    :cond_1d1
    iget v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadDpadHack:I

    const/4 v8, 0x1

    if-ne v7, v8, :cond_1f1

    .line 605
    const/high16 v7, 0x3f000000  # 0.5f

    cmpl-float v7, v0, v7

    if-gtz v7, :cond_1ee

    const/high16 v7, -0x41000000  # -0.5f

    cmpg-float v7, v0, v7

    if-ltz v7, :cond_1ee

    const/high16 v7, 0x3f000000  # 0.5f

    cmpl-float v7, v1, v7

    if-gtz v7, :cond_1ee

    const/high16 v7, -0x41000000  # -0.5f

    cmpg-float v7, v1, v7

    if-gez v7, :cond_37

    .line 606
    :cond_1ee
    const/4 v7, 0x0

    iput v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadDpadHack:I

    .line 611
    :cond_1f1
    const/high16 v7, 0x3f000000  # 0.5f

    cmpl-float v7, v0, v7

    if-lez v7, :cond_223

    iget v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    or-int/lit16 v7, v7, 0x800

    iput v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    .line 613
    :goto_1fd
    const/high16 v7, -0x41000000  # -0.5f

    cmpg-float v7, v0, v7

    if-gez v7, :cond_22a

    iget v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    or-int/lit16 v7, v7, 0x400

    iput v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    .line 615
    :goto_209
    const/high16 v7, 0x3f000000  # 0.5f

    cmpl-float v7, v1, v7

    if-lez v7, :cond_231

    iget v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    or-int/lit16 v7, v7, 0x200

    iput v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    .line 617
    :goto_215
    const/high16 v7, -0x41000000  # -0.5f

    cmpg-float v7, v1, v7

    if-gez v7, :cond_238

    iget v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    or-int/lit16 v7, v7, 0x100

    iput v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    goto/16 :goto_37

    .line 612
    :cond_223
    iget v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    and-int/lit16 v7, v7, -0x801

    iput v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    goto :goto_1fd

    .line 614
    :cond_22a
    iget v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    and-int/lit16 v7, v7, -0x401

    iput v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    goto :goto_209

    .line 616
    :cond_231
    iget v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    and-int/lit16 v7, v7, -0x201

    iput v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    goto :goto_215

    .line 618
    :cond_238
    iget v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    and-int/lit16 v7, v7, -0x101

    iput v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    goto/16 :goto_37
.end method

.method private sendCommand(II)V
    .registers 11
    .param p1, "index"  # I
    .param p2, "control"  # I

    .prologue
    .line 402
    monitor-enter p0

    .line 403
    const/16 v0, 0x40

    if-eq p2, v0, :cond_1d

    .line 404
    :try_start_5
    const-string v0, "WarGamepad"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "sendMove "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 406
    :cond_1d
    iget-object v0, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v0, v0, p1

    invoke-static {v0}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$300(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/hardware/usb/UsbDeviceConnection;

    move-result-object v0

    if-eqz v0, :cond_42

    .line 407
    const/4 v0, 0x1

    new-array v5, v0, [B

    .line 408
    .local v5, "message":[B
    const/4 v0, 0x0

    int-to-byte v1, p2

    aput-byte v1, v5, v0

    .line 410
    iget-object v0, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v0, v0, p1

    invoke-static {v0}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$300(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/hardware/usb/UsbDeviceConnection;

    move-result-object v0

    const/16 v1, 0x21

    const/16 v2, 0x9

    const/16 v3, 0x200

    const/4 v4, 0x0

    array-length v6, v5

    const/4 v7, 0x0

    invoke-virtual/range {v0 .. v7}, Landroid/hardware/usb/UsbDeviceConnection;->controlTransfer(IIII[BII)I

    .line 413
    .end local v5  # "message":[B
    :cond_42
    monitor-exit p0

    .line 414
    return-void

    .line 413
    :catchall_44
    move-exception v0

    monitor-exit p0
    :try_end_46
    .catchall {:try_start_5 .. :try_end_46} :catchall_44

    throw v0
.end method

.method private setProcessTouchpadAsPointer(Z)V
    .registers 8
    .param p1, "processAsPointer"  # Z

    .prologue
    .line 913
    :try_start_0
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_2} :catch_33

    const/16 v4, 0xd

    if-gt v3, v4, :cond_28

    .line 915
    :try_start_6
    invoke-virtual {p0}, Lcom/wardrumstudios/utils/WarGamepad;->getWindow()Landroid/view/Window;

    move-result-object v3

    invoke-virtual {v3}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v3

    invoke-virtual {v3}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v1

    .line 916
    .local v1, "root":Landroid/view/View;
    if-eqz v1, :cond_28

    .line 917
    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    .line 918
    .local v2, "viewRoot":Landroid/view/ViewParent;
    if-eqz v2, :cond_28

    .line 919
    invoke-virtual {p0, v2, p1}, Lcom/wardrumstudios/utils/WarGamepad;->processTouchpadAsPointer(Landroid/view/ViewParent;Z)Z

    move-result v3

    const/4 v4, 0x1

    if-ne v3, v4, :cond_29

    .line 921
    sget-object v3, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v4, "Processing touchpad as pointer succeeded"

    invoke-virtual {v3, v4}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    .line 933
    .end local v1  # "root":Landroid/view/View;
    .end local v2  # "viewRoot":Landroid/view/ViewParent;
    :cond_28
    :goto_28
    return-void

    .line 924
    .restart local v1  # "root":Landroid/view/View;
    .restart local v2  # "viewRoot":Landroid/view/ViewParent;
    :cond_29
    sget-object v3, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v4, "Processing touchpad as pointer failed"

    invoke-virtual {v3, v4}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V
    :try_end_30
    .catch Ljava/lang/NoClassDefFoundError; {:try_start_6 .. :try_end_30} :catch_31
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_30} :catch_33

    goto :goto_28

    .line 928
    .end local v1  # "root":Landroid/view/View;
    .end local v2  # "viewRoot":Landroid/view/ViewParent;
    :catch_31
    move-exception v3

    goto :goto_28

    .line 930
    :catch_33
    move-exception v0

    .line 931
    .local v0, "e":Ljava/lang/Exception;
    sget-object v3, Ljava/lang/System;->out:Ljava/io/PrintStream;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Unable to set processTouchpadAsPointer: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    goto :goto_28
.end method


# virtual methods
.method public CheckNavigation(Landroid/content/res/Configuration;)V
    .registers 7
    .param p1, "withConfig"  # Landroid/content/res/Configuration;

    .prologue
    const/4 v4, 0x1

    const/4 v3, -0x1

    const/4 v2, 0x0

    .line 891
    iget v0, p1, Landroid/content/res/Configuration;->navigationHidden:I

    if-ne v0, v4, :cond_33

    iget-object v0, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v0, v0, v2

    iget v0, v0, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    if-ne v0, v3, :cond_33

    .line 893
    const-string v0, "WarGamepad"

    const-string v1, "Attached xPeria play gamepad."

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 894
    iget-object v0, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v0, v0, v2

    iput v4, v0, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    .line 895
    iget-object v0, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v0, v0, v2

    iput-boolean v4, v0, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->is360:Z

    .line 896
    iget-object v0, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v0, v0, v2

    iput v2, v0, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    .line 897
    iget-object v0, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v0, v0, v2

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    iput-wide v2, v0, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->lastConnect:J

    .line 905
    :cond_32
    :goto_32
    return-void

    .line 898
    :cond_33
    iget v0, p1, Landroid/content/res/Configuration;->navigationHidden:I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_32

    iget-object v0, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v0, v0, v2

    iget v0, v0, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    if-eq v0, v3, :cond_32

    .line 900
    const-string v0, "WarGamepad"

    const-string v1, "Detaching xPeria play gamepad."

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 901
    iget-object v0, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v0, v0, v2

    iput v3, v0, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    .line 902
    iget-object v0, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v0, v0, v2

    iput v2, v0, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    .line 903
    iget-object v0, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v0, v0, v2

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    iput-wide v2, v0, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->lastDisconnect:J

    goto :goto_32
.end method

.method public GamepadReportSurfaceCreated(Landroid/view/SurfaceHolder;)V
    .registers 4
    .param p1, "holder"  # Landroid/view/SurfaceHolder;

    .prologue
    .line 938
    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v1, "Processing touchpad as pointer..."

    invoke-virtual {v0, v1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    .line 939
    const/4 v0, 0x1

    invoke-direct {p0, v0}, Lcom/wardrumstudios/utils/WarGamepad;->setProcessTouchpadAsPointer(Z)V

    .line 940
    return-void
.end method

.method GetDeviceIndex(II)I
    .registers 5
    .param p1, "deviceId"  # I
    .param p2, "source"  # I

    .prologue
    .line 161
    and-int/lit8 v1, p2, 0x10

    if-eqz v1, :cond_1d

    .line 162
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_5
    sget v1, Lcom/wardrumstudios/utils/WarGamepad;->MAX_GAME_PADS:I

    if-ge v0, v1, :cond_1d

    .line 163
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, v0

    iget-boolean v1, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->active:Z

    if-eqz v1, :cond_1a

    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, v0

    iget v1, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->deviceId:I

    if-ne v1, p1, :cond_1a

    .line 169
    .end local v0  # "i":I
    :goto_19
    return v0

    .line 162
    .restart local v0  # "i":I
    :cond_1a
    add-int/lit8 v0, v0, 0x1

    goto :goto_5

    .line 169
    .end local v0  # "i":I
    :cond_1d
    const/4 v0, -0x1

    goto :goto_19
.end method

.method GetDeviceIndexByName(Ljava/lang/String;)I
    .registers 3
    .param p1, "gamepadString"  # Ljava/lang/String;

    .prologue
    .line 173
    const/4 v0, -0x1

    return v0
.end method

.method GetFreeIndex(II)I
    .registers 6
    .param p1, "deviceId"  # I
    .param p2, "source"  # I

    .prologue
    const/4 v1, -0x1

    .line 183
    and-int/lit8 v2, p2, 0x10

    if-nez v2, :cond_7

    move v0, v1

    .line 199
    :cond_6
    :goto_6
    return v0

    .line 185
    :cond_7
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_8
    sget v2, Lcom/wardrumstudios/utils/WarGamepad;->MAX_GAME_PADS:I

    if-ge v0, v2, :cond_1f

    .line 186
    iget-object v2, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v2, v2, v0

    iget-boolean v2, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->active:Z

    if-eqz v2, :cond_1c

    iget-object v2, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v2, v2, v0

    iget v2, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->deviceId:I

    if-eq v2, p1, :cond_6

    .line 185
    :cond_1c
    add-int/lit8 v0, v0, 0x1

    goto :goto_8

    .line 191
    :cond_1f
    const/4 v0, 0x0

    :goto_20
    sget v2, Lcom/wardrumstudios/utils/WarGamepad;->MAX_GAME_PADS:I

    if-ge v0, v2, :cond_3d

    .line 192
    iget-object v2, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v2, v2, v0

    iget-boolean v2, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->active:Z

    if-nez v2, :cond_3a

    .line 193
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, v0

    iput p1, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->deviceId:I

    .line 194
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, v0

    const/4 v2, 0x1

    iput-boolean v2, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->active:Z

    goto :goto_6

    .line 191
    :cond_3a
    add-int/lit8 v0, v0, 0x1

    goto :goto_20

    :cond_3d
    move v0, v1

    .line 199
    goto :goto_6
.end method

.method public GetGamepadAxis(II)F
    .registers 4
    .param p1, "index"  # I
    .param p2, "axisId"  # I

    .prologue
    .line 1051
    iget-object v0, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v0, v0, p1

    iget-object v0, v0, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    aget v0, v0, p2

    return v0
.end method

.method public GetGamepadButtons(I)I
    .registers 3
    .param p1, "index"  # I

    .prologue
    .line 1047
    iget-object v0, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v0, v0, p1

    iget v0, v0, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    return v0
.end method

.method public GetGamepadTrack(III)I
    .registers 10
    .param p1, "index"  # I
    .param p2, "trackId"  # I
    .param p3, "coord"  # I

    .prologue
    const/4 v5, 0x4

    .line 1055
    iget-object v2, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v2, v2, p1

    iget v2, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->numGamepadTouchSamples:I

    if-ge v2, v5, :cond_b

    const/4 v2, 0x0

    .line 1062
    :goto_a
    return v2

    .line 1057
    :cond_b
    const/4 v0, 0x0

    .line 1058
    .local v0, "average":I
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_d
    if-ge v1, v5, :cond_21

    .line 1059
    iget-object v2, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v2, v2, p1

    iget-object v2, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadTouches:[I

    mul-int/lit8 v3, p2, 0x8

    mul-int/lit8 v4, v1, 0x2

    add-int/2addr v3, v4

    add-int/2addr v3, p3

    aget v2, v2, v3

    add-int/2addr v0, v2

    .line 1058
    add-int/lit8 v1, v1, 0x1

    goto :goto_d

    .line 1062
    :cond_21
    div-int/lit8 v2, v0, 0x4

    goto :goto_a
.end method

.method public GetGamepadType(I)I
    .registers 3
    .param p1, "index"  # I

    .prologue
    .line 1043
    iget-object v0, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v0, v0, p1

    iget v0, v0, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    return v0
.end method

.method GetMogaControllerType(I)I
    .registers 7
    .param p1, "index"  # I

    .prologue
    const/4 v2, 0x7

    const/4 v1, 0x4

    .line 1068
    iget-object v3, p0, Lcom/wardrumstudios/utils/WarGamepad;->mogaController:Lcom/bda/controller/Controller;

    invoke-virtual {v3, v1}, Lcom/bda/controller/Controller;->getState(I)I

    move-result v0

    .line 1069
    .local v0, "mogaType":I
    if-nez v0, :cond_b

    .line 1072
    :goto_a
    return v1

    .line 1070
    :cond_b
    const/4 v1, 0x1

    if-ne v0, v1, :cond_10

    move v1, v2

    goto :goto_a

    .line 1071
    :cond_10
    sget-object v1, Ljava/lang/System;->out:Ljava/io/PrintStream;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Moga controller type = "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    move v1, v2

    .line 1072
    goto :goto_a
.end method

.method GetWithDeadZone(F)F
    .registers 6
    .param p1, "x"  # F

    .prologue
    .line 1161
    float-to-double v0, p1

    const-wide/high16 v2, 0x3fd0000000000000L  # 0.25

    cmpl-double v0, v0, v2

    if-gtz v0, :cond_e

    float-to-double v0, p1

    const-wide/high16 v2, -0x4030000000000000L  # -0.25

    cmpg-double v0, v0, v2

    if-gez v0, :cond_f

    .line 1163
    .end local p1  # "x":F
    :cond_e
    :goto_e
    return p1

    .restart local p1  # "x":F
    :cond_f
    const/4 p1, 0x0

    goto :goto_e
.end method

.method public InitMogaController(I)I
    .registers 5
    .param p1, "index"  # I

    .prologue
    .line 204
    :try_start_0
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, p1

    invoke-static {p0}, Lcom/bda/controller/Controller;->getInstance(Landroid/content/Context;)Lcom/bda/controller/Controller;

    move-result-object v2

    iput-object v2, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->mogaController:Lcom/bda/controller/Controller;

    .line 205
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, p1

    iget-object v1, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->mogaController:Lcom/bda/controller/Controller;

    invoke-virtual {v1}, Lcom/bda/controller/Controller;->init()Z

    .line 206
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, p1

    iget-object v1, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->mogaController:Lcom/bda/controller/Controller;

    new-instance v2, Landroid/os/Handler;

    invoke-direct {v2}, Landroid/os/Handler;-><init>()V

    invoke-virtual {v1, p0, v2}, Lcom/bda/controller/Controller;->setListener(Lcom/bda/controller/ControllerListener;Landroid/os/Handler;)V

    .line 207
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, p1

    const/4 v2, 0x1

    iput-boolean v2, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->active:Z

    .line 208
    sget-object v1, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v2, "*****Set Moga as index 0"

    invoke-virtual {v1, v2}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V
    :try_end_2f
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_2f} :catch_30

    .line 213
    .end local p1  # "index":I
    :goto_2f
    return p1

    .line 209
    .restart local p1  # "index":I
    :catch_30
    move-exception v0

    .line 210
    .local v0, "ex":Ljava/lang/IllegalArgumentException;
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, p1

    const/4 v2, 0x0

    iput-object v2, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->mogaController:Lcom/bda/controller/Controller;

    .line 211
    const/4 p1, -0x1

    goto :goto_2f
.end method

.method public SetGamepad(Ljava/lang/String;)V
    .registers 5
    .param p1, "gamepadString"  # Ljava/lang/String;

    .prologue
    const/4 v2, -0x1

    .line 264
    invoke-virtual {p0, p1}, Lcom/wardrumstudios/utils/WarGamepad;->GetDeviceIndexByName(Ljava/lang/String;)I

    move-result v0

    .line 265
    .local v0, "index":I
    if-ne v0, v2, :cond_8

    .line 271
    :cond_7
    :goto_7
    return-void

    .line 266
    :cond_8
    const-string v1, "GS controller"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_18

    .line 267
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, v0

    const/4 v2, 0x3

    iput v2, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    goto :goto_7

    .line 268
    :cond_18
    const-string v1, ""

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7

    .line 269
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, v0

    iput v2, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    goto :goto_7
.end method

.method public SetReportPS3As360(Z)V
    .registers 4
    .param p1, "reportPS3as360"  # Z

    .prologue
    .line 177
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_1
    sget v1, Lcom/wardrumstudios/utils/WarGamepad;->MAX_GAME_PADS:I

    if-ge v0, v1, :cond_e

    .line 178
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, v0

    iput-boolean p1, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->reportPS3as360:Z

    .line 177
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 180
    :cond_e
    return-void
.end method

.method public TouchpadEvent(IIIIII)V
    .registers 12
    .param p1, "touchAction"  # I
    .param p2, "count"  # I
    .param p3, "x1"  # I
    .param p4, "y1"  # I
    .param p5, "x2"  # I
    .param p6, "y2"  # I

    .prologue
    const/4 v4, 0x1

    const/4 v3, 0x0

    .line 995
    if-eqz p1, :cond_6

    if-ne p1, v4, :cond_15

    .line 996
    :cond_6
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, v3

    iput v3, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->numGamepadTouchSamples:I

    .line 998
    if-ne p1, v4, :cond_1f

    .line 999
    invoke-virtual {p0, v3, v3, v3, v4}, Lcom/wardrumstudios/utils/WarGamepad;->UpdateTrack(IIIZ)V

    .line 1000
    invoke-virtual {p0, v4, v3, v3, v4}, Lcom/wardrumstudios/utils/WarGamepad;->UpdateTrack(IIIZ)V

    .line 1023
    :goto_14
    return-void

    .line 1004
    :cond_15
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, v3

    iget v2, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->numGamepadTouchSamples:I

    add-int/lit8 v2, v2, 0x1

    iput v2, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->numGamepadTouchSamples:I

    .line 1007
    :cond_1f
    const/4 v0, 0x0

    .line 1008
    .local v0, "fullChange":Z
    const/4 v1, 0x6

    if-ne p1, v1, :cond_39

    .line 1009
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, v3

    iput-boolean v4, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadTouchReversed:Z

    .line 1010
    const/4 v0, 0x1

    .line 1016
    :cond_2a
    :goto_2a
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, v3

    iget-boolean v1, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadTouchReversed:Z

    if-eqz v1, :cond_47

    .line 1017
    invoke-virtual {p0, v4, p3, p4, v0}, Lcom/wardrumstudios/utils/WarGamepad;->UpdateTrack(IIIZ)V

    .line 1018
    invoke-virtual {p0, v3, p5, p6, v0}, Lcom/wardrumstudios/utils/WarGamepad;->UpdateTrack(IIIZ)V

    goto :goto_14

    .line 1011
    :cond_39
    const/4 v1, 0x5

    if-eq p1, v1, :cond_3f

    const/4 v1, 0x2

    if-eq p1, v1, :cond_2a

    .line 1012
    :cond_3f
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, v3

    iput-boolean v3, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadTouchReversed:Z

    .line 1013
    const/4 v0, 0x1

    goto :goto_2a

    .line 1020
    :cond_47
    invoke-virtual {p0, v3, p3, p4, v0}, Lcom/wardrumstudios/utils/WarGamepad;->UpdateTrack(IIIZ)V

    .line 1021
    invoke-virtual {p0, v4, p5, p6, v0}, Lcom/wardrumstudios/utils/WarGamepad;->UpdateTrack(IIIZ)V

    goto :goto_14
.end method

.method public USBDeviceAttached(Landroid/hardware/usb/UsbDevice;Ljava/lang/String;)V
    .registers 14
    .param p1, "device"  # Landroid/hardware/usb/UsbDevice;
    .param p2, "name"  # Ljava/lang/String;

    .prologue
    const/4 v10, 0x0

    const/4 v9, -0x1

    const/4 v8, 0x1

    const/4 v7, 0x0

    .line 276
    const-string v4, "WarGamepad"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Device Attached : "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 278
    if-nez p1, :cond_26

    .line 279
    const-string v4, "WarGamepad"

    const-string v5, "Given null device?"

    invoke-static {v4, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 340
    :cond_25
    :goto_25
    return-void

    .line 288
    :cond_26
    invoke-virtual {p1}, Landroid/hardware/usb/UsbDevice;->getInterfaceCount()I

    move-result v4

    if-eq v4, v8, :cond_34

    .line 289
    const-string v4, "WarGamepad"

    const-string v5, "could not find interface"

    invoke-static {v4, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_25

    .line 293
    :cond_34
    invoke-virtual {p1, v7}, Landroid/hardware/usb/UsbDevice;->getInterface(I)Landroid/hardware/usb/UsbInterface;

    move-result-object v3

    .line 295
    .local v3, "intf":Landroid/hardware/usb/UsbInterface;
    invoke-virtual {v3}, Landroid/hardware/usb/UsbInterface;->getEndpointCount()I

    move-result v4

    if-eq v4, v8, :cond_46

    .line 296
    const-string v4, "WarGamepad"

    const-string v5, "could not find endpoint"

    invoke-static {v4, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_25

    .line 300
    :cond_46
    invoke-virtual {v3, v7}, Landroid/hardware/usb/UsbInterface;->getEndpoint(I)Landroid/hardware/usb/UsbEndpoint;

    move-result-object v1

    .line 301
    .local v1, "ep":Landroid/hardware/usb/UsbEndpoint;
    invoke-virtual {v1}, Landroid/hardware/usb/UsbEndpoint;->getType()I

    move-result v4

    const/4 v5, 0x3

    if-eq v4, v5, :cond_59

    .line 302
    const-string v4, "WarGamepad"

    const-string v5, "endpoint is not interrupt type"

    invoke-static {v4, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_25

    .line 307
    :cond_59
    invoke-virtual {p1}, Landroid/hardware/usb/UsbDevice;->getDeviceId()I

    move-result v4

    const/16 v5, 0x10

    invoke-virtual {p0, v4, v5}, Lcom/wardrumstudios/utils/WarGamepad;->GetFreeIndex(II)I

    move-result v2

    .line 308
    .local v2, "index":I
    if-eq v2, v9, :cond_25

    .line 311
    iget-object v4, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v4, v4, v2

    iput-boolean v8, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->is360:Z

    .line 312
    iget-object v4, p0, Lcom/wardrumstudios/utils/WarGamepad;->mUsbManager:Landroid/hardware/usb/UsbManager;

    invoke-virtual {v4, p1}, Landroid/hardware/usb/UsbManager;->openDevice(Landroid/hardware/usb/UsbDevice;)Landroid/hardware/usb/UsbDeviceConnection;

    move-result-object v0

    .line 313
    .local v0, "connection":Landroid/hardware/usb/UsbDeviceConnection;
    if-eqz v0, :cond_fd

    invoke-virtual {v0, v3, v8}, Landroid/hardware/usb/UsbDeviceConnection;->claimInterface(Landroid/hardware/usb/UsbInterface;Z)Z

    move-result v4

    if-eqz v4, :cond_fd

    .line 314
    const-string v4, "WarGamepad"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Success, I have a USB gamepad "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {p1}, Landroid/hardware/usb/UsbDevice;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 315
    iget-object v4, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v4, v4, v2

    iput v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    .line 316
    invoke-virtual {p1}, Landroid/hardware/usb/UsbDevice;->toString()Ljava/lang/String;

    move-result-object v4

    const-string v5, "PLAYSTATION"

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_bd

    .line 317
    iget-object v4, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v4, v4, v2

    iput-boolean v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->is360:Z

    .line 318
    iget-object v4, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v4, v4, v2

    iget-boolean v4, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->reportPS3as360:Z

    if-nez v4, :cond_bd

    iget-object v4, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v4, v4, v2

    const/16 v5, 0x8

    iput v5, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    .line 320
    :cond_bd
    iget-object v4, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v4, v4, v2

    invoke-static {v4, p1}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$102(Lcom/wardrumstudios/utils/WarGamepad$GamePad;Landroid/hardware/usb/UsbDevice;)Landroid/hardware/usb/UsbDevice;

    .line 321
    iget-object v4, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v4, v4, v2

    invoke-static {v4, v1}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$202(Lcom/wardrumstudios/utils/WarGamepad$GamePad;Landroid/hardware/usb/UsbEndpoint;)Landroid/hardware/usb/UsbEndpoint;

    .line 322
    iget-object v4, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v4, v4, v2

    invoke-static {v4, v0}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$302(Lcom/wardrumstudios/utils/WarGamepad$GamePad;Landroid/hardware/usb/UsbDeviceConnection;)Landroid/hardware/usb/UsbDeviceConnection;

    .line 323
    iget-object v4, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v4, v4, v2

    new-instance v5, Ljava/lang/Thread;

    new-instance v6, Lcom/wardrumstudios/utils/WarGamepad$1;

    invoke-direct {v6, p0, v2}, Lcom/wardrumstudios/utils/WarGamepad$1;-><init>(Lcom/wardrumstudios/utils/WarGamepad;I)V

    invoke-direct {v5, v6}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-static {v4, v5}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$402(Lcom/wardrumstudios/utils/WarGamepad$GamePad;Ljava/lang/Thread;)Ljava/lang/Thread;

    .line 328
    iget-object v4, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v4, v4, v2

    invoke-static {v4}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$400(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Ljava/lang/Thread;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Thread;->start()V

    .line 330
    iget-object v4, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v4, v4, v2

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v6

    iput-wide v6, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->lastConnect:J

    .line 339
    :goto_f8
    invoke-super {p0, p1, p2}, Lcom/wardrumstudios/utils/WarBilling;->USBDeviceAttached(Landroid/hardware/usb/UsbDevice;Ljava/lang/String;)V

    goto/16 :goto_25

    .line 332
    :cond_fd
    const-string v4, "WarGamepad"

    const-string v5, "Failed to open USB gamepad"

    invoke-static {v4, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 333
    iget-object v4, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v4, v4, v2

    iput v9, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    .line 334
    iget-object v4, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v4, v4, v2

    invoke-static {v4, v10}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$102(Lcom/wardrumstudios/utils/WarGamepad$GamePad;Landroid/hardware/usb/UsbDevice;)Landroid/hardware/usb/UsbDevice;

    .line 335
    iget-object v4, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v4, v4, v2

    invoke-static {v4, v10}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$302(Lcom/wardrumstudios/utils/WarGamepad$GamePad;Landroid/hardware/usb/UsbDeviceConnection;)Landroid/hardware/usb/UsbDeviceConnection;

    .line 336
    iget-object v4, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v4, v4, v2

    iput-boolean v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->active:Z

    goto :goto_f8
.end method

.method public USBDeviceDetached(Landroid/hardware/usb/UsbDevice;Ljava/lang/String;)V
    .registers 8
    .param p1, "device"  # Landroid/hardware/usb/UsbDevice;
    .param p2, "name"  # Ljava/lang/String;

    .prologue
    const/4 v4, 0x0

    const/4 v3, -0x1

    .line 344
    invoke-virtual {p1}, Landroid/hardware/usb/UsbDevice;->getDeviceId()I

    move-result v1

    const/16 v2, 0x10

    invoke-virtual {p0, v1, v2}, Lcom/wardrumstudios/utils/WarGamepad;->GetDeviceIndex(II)I

    move-result v0

    .line 345
    .local v0, "index":I
    if-ne v0, v3, :cond_16

    .line 346
    const-string v1, "WarGamepad"

    const-string v2, "Disconnected gamepad, device not connected"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 363
    :goto_15
    return-void

    .line 349
    :cond_16
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, v0

    iget v1, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    if-eq v1, v3, :cond_58

    .line 350
    const-string v1, "WarGamepad"

    const-string v2, "Disconnected gamepad, stopping usb thread"

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 352
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, v0

    iput v3, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    .line 353
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, v0

    const/4 v2, 0x0

    invoke-static {v1, v2}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$102(Lcom/wardrumstudios/utils/WarGamepad$GamePad;Landroid/hardware/usb/UsbDevice;)Landroid/hardware/usb/UsbDevice;

    .line 354
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, v0

    iput v4, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    .line 356
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, v0

    invoke-static {v1}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$400(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Ljava/lang/Thread;

    move-result-object v1

    if-eqz v1, :cond_4e

    .line 357
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, v0

    invoke-static {v1}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$400(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Ljava/lang/Thread;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Thread;->stop()V

    .line 359
    :cond_4e
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, v0

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    iput-wide v2, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->lastDisconnect:J

    .line 361
    :cond_58
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, v0

    iput-boolean v4, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->active:Z

    .line 362
    invoke-super {p0, p1, p2}, Lcom/wardrumstudios/utils/WarBilling;->USBDeviceDetached(Landroid/hardware/usb/UsbDevice;Ljava/lang/String;)V

    goto :goto_15
.end method

.method public USBDeviceRun(I)V
    .registers 10
    .param p1, "index"  # I

    .prologue
    const/4 v7, 0x1

    .line 369
    invoke-static {v7}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v0

    .line 370
    .local v0, "buffer":Ljava/nio/ByteBuffer;
    new-instance v2, Landroid/hardware/usb/UsbRequest;

    invoke-direct {v2}, Landroid/hardware/usb/UsbRequest;-><init>()V

    .line 371
    .local v2, "request":Landroid/hardware/usb/UsbRequest;
    iget-object v4, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v4, v4, p1

    invoke-static {v4}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$300(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/hardware/usb/UsbDeviceConnection;

    move-result-object v4

    iget-object v5, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v5, v5, p1

    invoke-static {v5}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$200(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/hardware/usb/UsbEndpoint;

    move-result-object v5

    invoke-virtual {v2, v4, v5}, Landroid/hardware/usb/UsbRequest;->initialize(Landroid/hardware/usb/UsbDeviceConnection;Landroid/hardware/usb/UsbEndpoint;)Z

    .line 372
    const/4 v3, -0x1

    .line 375
    .local v3, "status":B
    :goto_1e
    invoke-virtual {v2, v0, v7}, Landroid/hardware/usb/UsbRequest;->queue(Ljava/nio/ByteBuffer;I)Z

    .line 377
    const/16 v4, 0x40

    invoke-direct {p0, p1, v4}, Lcom/wardrumstudios/utils/WarGamepad;->sendCommand(II)V

    .line 379
    iget-object v4, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v4, v4, p1

    invoke-static {v4}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$300(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/hardware/usb/UsbDeviceConnection;

    move-result-object v4

    invoke-virtual {v4}, Landroid/hardware/usb/UsbDeviceConnection;->requestWait()Landroid/hardware/usb/UsbRequest;

    move-result-object v4

    if-ne v4, v2, :cond_7d

    .line 380
    const/4 v4, 0x0

    invoke-virtual {v0, v4}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v1

    .line 381
    .local v1, "newStatus":B
    const-string v4, "WarGamepad"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "****got status "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 382
    if-eq v1, v3, :cond_75

    .line 383
    const-string v4, "WarGamepad"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "got status "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 384
    move v3, v1

    .line 385
    and-int/lit8 v4, v3, 0x10

    if-eqz v4, :cond_75

    .line 387
    const/16 v4, 0x20

    invoke-direct {p0, p1, v4}, Lcom/wardrumstudios/utils/WarGamepad;->sendCommand(II)V

    .line 391
    :cond_75
    const-wide/16 v4, 0x64

    :try_start_77
    invoke-static {v4, v5}, Ljava/lang/Thread;->sleep(J)V
    :try_end_7a
    .catch Ljava/lang/InterruptedException; {:try_start_77 .. :try_end_7a} :catch_7b

    goto :goto_1e

    .line 392
    :catch_7b
    move-exception v4

    goto :goto_1e

    .line 395
    .end local v1  # "newStatus":B
    :cond_7d
    const-string v4, "WarGamepad"

    const-string v5, "requestWait failed, exiting"

    invoke-static {v4, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 399
    return-void
.end method

.method public UpdateTrack(IIIZ)V
    .registers 10
    .param p1, "trackNo"  # I
    .param p2, "x"  # I
    .param p3, "y"  # I
    .param p4, "fullChange"  # Z

    .prologue
    const/4 v4, 0x0

    .line 1026
    if-eqz p4, :cond_22

    .line 1027
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_4
    const/4 v2, 0x4

    if-ge v0, v2, :cond_42

    .line 1028
    mul-int/lit8 v2, p1, 0x8

    mul-int/lit8 v3, v0, 0x2

    add-int v1, v2, v3

    .line 1030
    .local v1, "index":I
    iget-object v2, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v2, v2, v4

    iget-object v2, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadTouches:[I

    aput p2, v2, v1

    .line 1031
    iget-object v2, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v2, v2, v4

    iget-object v2, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadTouches:[I

    add-int/lit8 v3, v1, 0x1

    aput p3, v2, v3

    .line 1027
    add-int/lit8 v0, v0, 0x1

    goto :goto_4

    .line 1034
    .end local v0  # "i":I
    .end local v1  # "index":I
    :cond_22
    mul-int/lit8 v2, p1, 0x8

    iget-object v3, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v3, v3, v4

    iget v3, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->numGamepadTouchSamples:I

    rem-int/lit8 v3, v3, 0x4

    mul-int/lit8 v3, v3, 0x2

    add-int v1, v2, v3

    .line 1036
    .restart local v1  # "index":I
    iget-object v2, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v2, v2, v4

    iget-object v2, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadTouches:[I

    aput p2, v2, v1

    .line 1037
    iget-object v2, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v2, v2, v4

    iget-object v2, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadTouches:[I

    add-int/lit8 v3, v1, 0x1

    aput p3, v2, v3

    .line 1039
    .end local v1  # "index":I
    :cond_42
    return-void
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .registers 4
    .param p1, "newConfig"  # Landroid/content/res/Configuration;

    .prologue
    .line 883
    iget-object v0, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    invoke-static {v0}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$000(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Z

    move-result v0

    if-eqz v0, :cond_e

    .line 884
    invoke-virtual {p0, p1}, Lcom/wardrumstudios/utils/WarGamepad;->CheckNavigation(Landroid/content/res/Configuration;)V

    .line 887
    :cond_e
    invoke-super {p0, p1}, Lcom/wardrumstudios/utils/WarBilling;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    .line 888
    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .registers 7
    .param p1, "savedInstanceState"  # Landroid/os/Bundle;

    .prologue
    .line 220
    invoke-super {p0, p1}, Lcom/wardrumstudios/utils/WarBilling;->onCreate(Landroid/os/Bundle;)V

    .line 223
    :try_start_3
    invoke-static {p0}, Lcom/bda/controller/Controller;->getInstance(Landroid/content/Context;)Lcom/bda/controller/Controller;

    move-result-object v2

    iput-object v2, p0, Lcom/wardrumstudios/utils/WarGamepad;->mogaController:Lcom/bda/controller/Controller;

    .line 224
    iget-object v2, p0, Lcom/wardrumstudios/utils/WarGamepad;->mogaController:Lcom/bda/controller/Controller;

    invoke-virtual {v2}, Lcom/bda/controller/Controller;->init()Z

    .line 225
    iget-object v2, p0, Lcom/wardrumstudios/utils/WarGamepad;->mogaController:Lcom/bda/controller/Controller;

    new-instance v3, Landroid/os/Handler;

    invoke-direct {v3}, Landroid/os/Handler;-><init>()V

    invoke-virtual {v2, p0, v3}, Lcom/bda/controller/Controller;->setListener(Lcom/bda/controller/ControllerListener;Landroid/os/Handler;)V
    :try_end_18
    .catch Ljava/lang/IllegalArgumentException; {:try_start_3 .. :try_end_18} :catch_2f

    .line 231
    :goto_18
    sget v2, Lcom/wardrumstudios/utils/WarGamepad;->MAX_GAME_PADS:I

    new-array v2, v2, [Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    iput-object v2, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    .line 232
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_1f
    sget v2, Lcom/wardrumstudios/utils/WarGamepad;->MAX_GAME_PADS:I

    if-ge v1, v2, :cond_34

    .line 233
    iget-object v2, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    new-instance v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    invoke-direct {v3, p0}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;-><init>(Lcom/wardrumstudios/utils/WarGamepad;)V

    aput-object v3, v2, v1

    .line 232
    add-int/lit8 v1, v1, 0x1

    goto :goto_1f

    .line 226
    .end local v1  # "i":I
    :catch_2f
    move-exception v0

    .line 227
    .local v0, "ex":Ljava/lang/IllegalArgumentException;
    const/4 v2, 0x0

    iput-object v2, p0, Lcom/wardrumstudios/utils/WarGamepad;->mogaController:Lcom/bda/controller/Controller;

    goto :goto_18

    .line 237
    .end local v0  # "ex":Ljava/lang/IllegalArgumentException;
    .restart local v1  # "i":I
    :cond_34
    sget-object v2, Landroid/os/Build;->PRODUCT:Ljava/lang/String;

    const-string v3, "R800"

    invoke-virtual {v2, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_5a

    .line 238
    const-string v2, "WarGamepad"

    const-string v3, "Xperia Play detected."

    invoke-static {v2, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 239
    iget-object v2, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    const/4 v3, 0x0

    aget-object v2, v2, v3

    const/4 v3, 0x1

    invoke-static {v2, v3}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$002(Lcom/wardrumstudios/utils/WarGamepad$GamePad;Z)Z

    .line 240
    invoke-virtual {p0}, Lcom/wardrumstudios/utils/WarGamepad;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v2

    invoke-virtual {p0, v2}, Lcom/wardrumstudios/utils/WarGamepad;->CheckNavigation(Landroid/content/res/Configuration;)V

    .line 246
    :goto_59
    return-void

    .line 242
    :cond_5a
    const-string v2, "WarGamepad"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Product "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    sget-object v4, Landroid/os/Build;->PRODUCT:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 243
    const-string v2, "WarGamepad"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Device "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    sget-object v4, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_59
.end method

.method public onDestroy()V
    .registers 3

    .prologue
    .line 251
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->mogaController:Lcom/bda/controller/Controller;

    if-eqz v1, :cond_9

    .line 252
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->mogaController:Lcom/bda/controller/Controller;

    invoke-virtual {v1}, Lcom/bda/controller/Controller;->exit()V

    .line 254
    :cond_9
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_a
    sget v1, Lcom/wardrumstudios/utils/WarGamepad;->MAX_GAME_PADS:I

    if-ge v0, v1, :cond_22

    .line 255
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, v0

    iget-object v1, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->mogaController:Lcom/bda/controller/Controller;

    if-eqz v1, :cond_1f

    .line 256
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, v0

    iget-object v1, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->mogaController:Lcom/bda/controller/Controller;

    invoke-virtual {v1}, Lcom/bda/controller/Controller;->exit()V

    .line 254
    :cond_1f
    add-int/lit8 v0, v0, 0x1

    goto :goto_a

    .line 259
    :cond_22
    invoke-super {p0}, Lcom/wardrumstudios/utils/WarBilling;->onDestroy()V

    .line 260
    return-void
.end method

.method public onGenericMotionEvent(Landroid/view/MotionEvent;)Z
    .registers 14
    .param p1, "event"  # Landroid/view/MotionEvent;

    .prologue
    .line 421
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getDeviceId()I

    move-result v8

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getSource()I

    move-result v9

    invoke-virtual {p0, v8, v9}, Lcom/wardrumstudios/utils/WarGamepad;->GetDeviceIndex(II)I

    move-result v4

    .line 422
    .local v4, "index":I
    const/4 v8, -0x1

    if-ne v4, v8, :cond_4f

    .line 423
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getDevice()Landroid/view/InputDevice;

    move-result-object v8

    if-eqz v8, :cond_4d

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getDevice()Landroid/view/InputDevice;

    move-result-object v8

    invoke-virtual {v8}, Landroid/view/InputDevice;->getSources()I

    move-result v7

    .line 424
    .local v7, "source":I
    :goto_1d
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getDeviceId()I

    move-result v8

    invoke-virtual {p0, v8, v7}, Lcom/wardrumstudios/utils/WarGamepad;->GetFreeIndex(II)I

    move-result v4

    .line 425
    const/4 v8, -0x1

    if-ne v4, v8, :cond_4f

    .line 426
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getSource()I

    move-result v8

    and-int/lit8 v8, v8, 0x10

    if-eqz v8, :cond_48

    .line 427
    sget-object v8, Ljava/lang/System;->out:Ljava/io/PrintStream;

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "********************ERROR********* cannot assign controller MotionEvent "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    .line 429
    :cond_48
    invoke-super {p0, p1}, Lcom/wardrumstudios/utils/WarBilling;->onGenericMotionEvent(Landroid/view/MotionEvent;)Z

    move-result v8

    .line 523
    .end local v7  # "source":I
    :goto_4c
    return v8

    .line 423
    :cond_4d
    const/4 v7, 0x0

    goto :goto_1d

    .line 432
    :cond_4f
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    invoke-static {v8}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$000(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Z

    move-result v8

    if-eqz v8, :cond_5b

    .line 433
    const/4 v8, 0x0

    goto :goto_4c

    .line 440
    :cond_5b
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getSource()I

    move-result v8

    and-int/lit8 v8, v8, 0x10

    if-eqz v8, :cond_257

    .line 441
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v8

    const/4 v9, 0x2

    if-ne v8, v9, :cond_257

    .line 446
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    invoke-static {v8}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v8

    if-eqz v8, :cond_86

    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    invoke-static {v8}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v8

    invoke-virtual {v8}, Landroid/view/InputDevice;->getId()I

    move-result v8

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getDeviceId()I

    move-result v9

    if-eq v8, v9, :cond_c6

    .line 447
    :cond_86
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getDevice()Landroid/view/InputDevice;

    move-result-object v9

    invoke-static {v8, v9}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$502(Lcom/wardrumstudios/utils/WarGamepad$GamePad;Landroid/view/InputDevice;)Landroid/view/InputDevice;

    .line 450
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    invoke-static {v8}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v8

    if-nez v8, :cond_9d

    .line 451
    const/4 v8, 0x0

    goto :goto_4c

    .line 455
    :cond_9d
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    const/4 v9, -0x1

    iput v9, v8, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    .line 456
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    const/4 v9, 0x0

    iput-boolean v9, v8, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->mightBeNyko:Z

    .line 457
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    invoke-static {v8}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v8

    invoke-virtual {v8}, Landroid/view/InputDevice;->getName()Ljava/lang/String;

    move-result-object v8

    const-string v9, "NYKO"

    invoke-virtual {v8, v9}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    if-eqz v8, :cond_14f

    .line 458
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    const/4 v9, 0x6

    iput v9, v8, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    .line 475
    :cond_c6
    :goto_c6
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    iget v8, v8, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    const/4 v9, -0x1

    if-eq v8, v9, :cond_e2

    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    iget v8, v8, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    const/16 v9, 0xb

    if-eq v8, v9, :cond_e2

    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    iget v8, v8, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    const/4 v9, 0x3

    if-ne v8, v9, :cond_129

    .line 476
    :cond_e2
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getDevice()Landroid/view/InputDevice;

    move-result-object v9

    invoke-static {v8, v9}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$502(Lcom/wardrumstudios/utils/WarGamepad$GamePad;Landroid/view/InputDevice;)Landroid/view/InputDevice;

    .line 477
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    invoke-static {v8}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v8

    invoke-virtual {v8}, Landroid/view/InputDevice;->getName()Ljava/lang/String;

    move-result-object v6

    .line 478
    .local v6, "name":Ljava/lang/String;
    const-string v8, "Thunder"

    invoke-virtual {v6, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    if-nez v8, :cond_109

    const-string v8, "Amazon Fire Game Controller"

    invoke-virtual {v6, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    if-eqz v8, :cond_129

    .line 479
    :cond_109
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    const/16 v9, 0xc

    iput v9, v8, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    .line 480
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    const/4 v9, 0x0

    iput v9, v8, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    .line 481
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v10

    iput-wide v10, v8, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->lastConnect:J

    .line 482
    sget-object v8, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v9, "Setting GamepadType to Amazon Controller"

    invoke-virtual {v8, v9}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    .line 486
    .end local v6  # "name":Ljava/lang/String;
    :cond_129
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    iget v8, v8, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    const/4 v9, -0x1

    if-eq v8, v9, :cond_13b

    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    iget v8, v8, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    const/4 v9, 0x3

    if-ne v8, v9, :cond_239

    .line 487
    :cond_13b
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v8

    iget-object v10, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v10, v10, v4

    iget-wide v10, v10, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->lastDisconnect:J

    sub-long/2addr v8, v10

    const-wide/16 v10, 0xfa

    cmp-long v8, v8, v10

    if-gez v8, :cond_191

    .line 489
    const/4 v8, 0x0

    goto/16 :goto_4c

    .line 461
    :cond_14f
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    invoke-static {v8}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v8

    invoke-virtual {v8}, Landroid/view/InputDevice;->getName()Ljava/lang/String;

    move-result-object v8

    const-string v9, "Broadcom Bluetooth HID"

    invoke-virtual {v8, v9}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    .line 462
    .local v5, "isBroadcom":Z
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    invoke-static {v8}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v8

    const/16 v9, 0x16

    invoke-virtual {v8, v9}, Landroid/view/InputDevice;->getMotionRange(I)Landroid/view/InputDevice$MotionRange;

    move-result-object v1

    .line 463
    .local v1, "gas":Landroid/view/InputDevice$MotionRange;
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    invoke-static {v8}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v8

    const/16 v9, 0x17

    invoke-virtual {v8, v9}, Landroid/view/InputDevice;->getMotionRange(I)Landroid/view/InputDevice$MotionRange;

    move-result-object v0

    .line 465
    .local v0, "brake":Landroid/view/InputDevice$MotionRange;
    if-eqz v1, :cond_c6

    if-eqz v0, :cond_c6

    .line 466
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    const/4 v9, 0x1

    iput-boolean v9, v8, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->mightBeNyko:Z

    .line 467
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    const/4 v9, 0x0

    iput v9, v8, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->NykoCheckHacks:I

    goto/16 :goto_c6

    .line 492
    .end local v0  # "brake":Landroid/view/InputDevice$MotionRange;
    .end local v1  # "gas":Landroid/view/InputDevice$MotionRange;
    .end local v5  # "isBroadcom":Z
    :cond_191
    :try_start_191
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getDevice()Landroid/view/InputDevice;

    move-result-object v9

    invoke-static {v8, v9}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$502(Lcom/wardrumstudios/utils/WarGamepad$GamePad;Landroid/view/InputDevice;)Landroid/view/InputDevice;

    .line 493
    const-string v8, "WarGamepad"

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "FIXME! Received joystick event without a valid joystick. "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    iget-object v10, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v10, v10, v4

    invoke-static {v10}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v8, v9}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 495
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    const/4 v9, 0x0

    iput v9, v8, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    .line 496
    iget-boolean v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->IsAndroidTV:Z

    if-eqz v8, :cond_1cf

    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    const/16 v9, 0xd

    iput v9, v8, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    .line 498
    :cond_1cf
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    invoke-static {v8}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v8

    if-eqz v8, :cond_228

    .line 499
    const-string v8, "WarGamepad"

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "mLastGamepadInputDevice.getName() "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    iget-object v10, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v10, v10, v4

    invoke-static {v10}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v10

    invoke-virtual {v10}, Landroid/view/InputDevice;->getName()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v8, v9}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 500
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    invoke-static {v8}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v8

    invoke-virtual {v8}, Landroid/view/InputDevice;->getName()Ljava/lang/String;

    move-result-object v8

    const-string v9, "PLAYSTATION"

    invoke-virtual {v8, v9}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    if-eqz v8, :cond_246

    .line 501
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    const/4 v9, 0x0

    iput-boolean v9, v8, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->is360:Z

    .line 502
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    iget-boolean v8, v8, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->reportPS3as360:Z

    if-nez v8, :cond_228

    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    const/16 v9, 0x8

    iput v9, v8, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    .line 506
    :cond_228
    :goto_228
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    const/4 v9, 0x0

    iput v9, v8, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    .line 507
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v10

    iput-wide v10, v8, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->lastConnect:J
    :try_end_239
    .catch Ljava/lang/Exception; {:try_start_191 .. :try_end_239} :catch_24e

    .line 513
    :cond_239
    :goto_239
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getHistorySize()I

    move-result v2

    .line 514
    .local v2, "historySize":I
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_23e
    if-ge v3, v2, :cond_250

    .line 515
    invoke-direct {p0, p1, v3}, Lcom/wardrumstudios/utils/WarGamepad;->processJoystickInput(Landroid/view/MotionEvent;I)V

    .line 514
    add-int/lit8 v3, v3, 0x1

    goto :goto_23e

    .line 503
    .end local v2  # "historySize":I
    .end local v3  # "i":I
    :cond_246
    :try_start_246
    iget-object v8, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v8, v8, v4

    const/4 v9, 0x1

    iput-boolean v9, v8, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->is360:Z
    :try_end_24d
    .catch Ljava/lang/Exception; {:try_start_246 .. :try_end_24d} :catch_24e

    goto :goto_228

    .line 508
    :catch_24e
    move-exception v8

    goto :goto_239

    .line 519
    .restart local v2  # "historySize":I
    .restart local v3  # "i":I
    :cond_250
    const/4 v8, -0x1

    invoke-direct {p0, p1, v8}, Lcom/wardrumstudios/utils/WarGamepad;->processJoystickInput(Landroid/view/MotionEvent;I)V

    .line 520
    const/4 v8, 0x1

    goto/16 :goto_4c

    .line 523
    .end local v2  # "historySize":I
    .end local v3  # "i":I
    :cond_257
    invoke-super {p0, p1}, Lcom/wardrumstudios/utils/WarBilling;->onGenericMotionEvent(Landroid/view/MotionEvent;)Z

    move-result v8

    goto/16 :goto_4c
.end method

.method public onKeyDown(ILandroid/view/KeyEvent;)Z
    .registers 15
    .param p1, "keyCode"  # I
    .param p2, "keyEvent"  # Landroid/view/KeyEvent;

    .prologue
    .line 737
    invoke-virtual {p2}, Landroid/view/KeyEvent;->getDeviceId()I

    move-result v7

    invoke-virtual {p2}, Landroid/view/KeyEvent;->getSource()I

    move-result v8

    invoke-virtual {p0, v7, v8}, Lcom/wardrumstudios/utils/WarGamepad;->GetDeviceIndex(II)I

    move-result v2

    .line 738
    .local v2, "index":I
    const/4 v7, -0x1

    if-ne v2, v7, :cond_57

    .line 739
    invoke-virtual {p2}, Landroid/view/KeyEvent;->getDevice()Landroid/view/InputDevice;

    move-result-object v7

    if-eqz v7, :cond_55

    invoke-virtual {p2}, Landroid/view/KeyEvent;->getDevice()Landroid/view/InputDevice;

    move-result-object v7

    invoke-virtual {v7}, Landroid/view/InputDevice;->getSources()I

    move-result v6

    .line 740
    .local v6, "source":I
    :goto_1d
    invoke-virtual {p2}, Landroid/view/KeyEvent;->getDeviceId()I

    move-result v7

    invoke-virtual {p2}, Landroid/view/KeyEvent;->getDevice()Landroid/view/InputDevice;

    move-result-object v8

    invoke-virtual {v8}, Landroid/view/InputDevice;->getSources()I

    move-result v8

    invoke-virtual {p0, v7, v8}, Lcom/wardrumstudios/utils/WarGamepad;->GetFreeIndex(II)I

    move-result v2

    .line 741
    const/4 v7, -0x1

    if-ne v2, v7, :cond_57

    .line 742
    invoke-virtual {p2}, Landroid/view/KeyEvent;->getSource()I

    move-result v7

    and-int/lit8 v7, v7, 0x10

    if-eqz v7, :cond_50

    .line 743
    sget-object v7, Ljava/lang/System;->out:Ljava/io/PrintStream;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "********************ERROR********* cannot assign controller keyEvent "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    .line 745
    :cond_50
    invoke-super {p0, p1, p2}, Lcom/wardrumstudios/utils/WarBilling;->onKeyDown(ILandroid/view/KeyEvent;)Z

    move-result v7

    .line 873
    .end local v6  # "source":I
    :goto_54
    return v7

    .line 739
    :cond_55
    const/4 v6, 0x0

    goto :goto_1d

    .line 748
    :cond_57
    iget-object v7, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v4, v7, v2

    .line 750
    .local v4, "myGamePad":Lcom/wardrumstudios/utils/WarGamepad$GamePad;
    const/4 v1, 0x0

    .line 756
    .local v1, "buttonMask":I
    :try_start_5c
    invoke-static {v4}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$000(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Z

    move-result v7

    if-nez v7, :cond_b5

    invoke-virtual {p2}, Landroid/view/KeyEvent;->getDeviceId()I

    move-result v7

    if-lez v7, :cond_b5

    iget v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    const/16 v8, 0xb

    if-eq v7, v8, :cond_b5

    .line 758
    const/4 v7, 0x7

    if-lt p1, v7, :cond_75

    const/16 v7, 0x10

    if-le p1, v7, :cond_95

    :cond_75
    const/16 v7, 0x14

    if-lt p1, v7, :cond_7d

    const/16 v7, 0x16

    if-le p1, v7, :cond_95

    :cond_7d
    const/16 v7, 0x25

    if-lt p1, v7, :cond_85

    const/16 v7, 0x28

    if-le p1, v7, :cond_95

    :cond_85
    const/16 v7, 0x2f

    if-eq p1, v7, :cond_95

    const/16 v7, 0x1d

    if-eq p1, v7, :cond_95

    const/16 v7, 0x20

    if-eq p1, v7, :cond_95

    const/16 v7, 0x33

    if-ne p1, v7, :cond_158

    :cond_95
    const/4 v3, 0x1

    .line 762
    .local v3, "mightBeGamestop":Z
    :goto_96
    invoke-virtual {p2}, Landroid/view/KeyEvent;->getDevice()Landroid/view/InputDevice;

    move-result-object v7

    if-eqz v7, :cond_15b

    invoke-virtual {p2}, Landroid/view/KeyEvent;->getDevice()Landroid/view/InputDevice;

    move-result-object v7

    invoke-virtual {v7}, Landroid/view/InputDevice;->getSources()I

    move-result v7

    and-int/lit8 v7, v7, 0x10

    if-eqz v7, :cond_15b

    .line 763
    iget v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    const/4 v8, -0x1

    if-eq v7, v8, :cond_b2

    iget v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    const/4 v8, 0x3

    if-ne v7, v8, :cond_b5

    :cond_b2
    const/4 v7, 0x5

    iput v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I
    :try_end_b5
    .catch Ljava/lang/NoSuchMethodError; {:try_start_5c .. :try_end_b5} :catch_162
    .catch Ljava/lang/Exception; {:try_start_5c .. :try_end_b5} :catch_190

    .line 774
    .end local v3  # "mightBeGamestop":Z
    :cond_b5
    :goto_b5
    invoke-virtual {p2}, Landroid/view/KeyEvent;->getDevice()Landroid/view/InputDevice;

    move-result-object v7

    if-eqz v7, :cond_10d

    .line 776
    iget v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    const/4 v8, -0x1

    if-eq v7, v8, :cond_d1

    iget v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    const/16 v8, 0xc

    if-eq v7, v8, :cond_d1

    iget v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    const/16 v8, 0xb

    if-eq v7, v8, :cond_d1

    iget v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    const/4 v8, 0x3

    if-ne v7, v8, :cond_10d

    .line 778
    :cond_d1
    invoke-virtual {p2}, Landroid/view/KeyEvent;->getDevice()Landroid/view/InputDevice;

    move-result-object v7

    invoke-static {v4, v7}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$502(Lcom/wardrumstudios/utils/WarGamepad$GamePad;Landroid/view/InputDevice;)Landroid/view/InputDevice;

    .line 779
    invoke-static {v4}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v7

    if-eqz v7, :cond_10d

    .line 780
    invoke-static {v4}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v7

    invoke-virtual {v7}, Landroid/view/InputDevice;->getName()Ljava/lang/String;

    move-result-object v5

    .line 781
    .local v5, "name":Ljava/lang/String;
    iget v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    const/16 v8, 0xc

    if-eq v7, v8, :cond_193

    const-string v7, "Thunder"

    invoke-virtual {v5, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-nez v7, :cond_fc

    const-string v7, "Amazon Fire Game Controller"

    invoke-virtual {v5, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-eqz v7, :cond_193

    .line 782
    :cond_fc
    const/16 v7, 0xc

    iput v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    .line 783
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v8

    iput-wide v8, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->lastConnect:J

    .line 784
    sget-object v7, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v8, "Setting GamepadType to Amazon Controller onKeyDown"

    invoke-virtual {v7, v8}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    .line 797
    .end local v5  # "name":Ljava/lang/String;
    :cond_10d
    :goto_10d
    const/4 v0, 0x1

    .line 799
    .local v0, "bPS3Flipped":Z
    packed-switch p1, :pswitch_data_26e

    .line 818
    :goto_111
    :pswitch_111  #0x62, 0x65
    if-nez v1, :cond_121

    invoke-static {v4}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$000(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Z

    move-result v7

    if-nez v7, :cond_121

    .line 819
    packed-switch p1, :pswitch_data_28e

    .line 828
    :goto_11c
    if-eqz v1, :cond_121

    const/4 v7, 0x1

    iput v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadDpadHack:I

    .line 831
    :cond_121
    if-nez v1, :cond_131

    invoke-static {v4}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$000(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Z

    move-result v7

    if-eqz v7, :cond_131

    iget v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    const/4 v8, -0x1

    if-eq v7, v8, :cond_131

    .line 832
    sparse-switch p1, :sswitch_data_29c

    .line 853
    :cond_131
    :goto_131
    iget v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    const/4 v8, 0x3

    if-ne v7, v8, :cond_13e

    .line 854
    const/16 v7, 0x6f

    if-ne p1, v7, :cond_264

    .line 855
    or-int/lit8 v1, v1, 0x20

    .line 856
    const/16 p1, 0x6d

    .line 869
    :cond_13e
    :goto_13e
    if-eqz v1, :cond_152

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v8

    iget-wide v10, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->lastConnect:J

    sub-long/2addr v8, v10

    const-wide/16 v10, 0x3e8

    cmp-long v7, v8, v10

    if-lez v7, :cond_152

    .line 870
    iget v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    or-int/2addr v7, v1

    iput v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    .line 873
    :cond_152
    invoke-super {p0, p1, p2}, Lcom/wardrumstudios/utils/WarBilling;->onKeyDown(ILandroid/view/KeyEvent;)Z

    move-result v7

    goto/16 :goto_54

    .line 758
    .end local v0  # "bPS3Flipped":Z
    :cond_158
    const/4 v3, 0x0

    goto/16 :goto_96

    .line 765
    .restart local v3  # "mightBeGamestop":Z
    :cond_15b
    if-eqz v3, :cond_165

    .line 766
    const/4 v7, 0x3

    :try_start_15e
    iput v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    goto/16 :goto_b5

    .line 771
    .end local v3  # "mightBeGamestop":Z
    :catch_162
    move-exception v7

    goto/16 :goto_b5

    .line 767
    .restart local v3  # "mightBeGamestop":Z
    :cond_165
    invoke-virtual {p2}, Landroid/view/KeyEvent;->getDevice()Landroid/view/InputDevice;

    move-result-object v7

    if-eqz v7, :cond_b5

    invoke-virtual {p2}, Landroid/view/KeyEvent;->getDevice()Landroid/view/InputDevice;

    move-result-object v7

    invoke-virtual {v7}, Landroid/view/InputDevice;->getName()Ljava/lang/String;

    move-result-object v7

    const-string v8, "GS controller"

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_18b

    invoke-virtual {p2}, Landroid/view/KeyEvent;->getDevice()Landroid/view/InputDevice;

    move-result-object v7

    invoke-virtual {v7}, Landroid/view/InputDevice;->getName()Ljava/lang/String;

    move-result-object v7

    const-string v8, "Broadcom Bluetooth HID"

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_b5

    .line 768
    :cond_18b
    const/4 v7, 0x3

    iput v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I
    :try_end_18e
    .catch Ljava/lang/NoSuchMethodError; {:try_start_15e .. :try_end_18e} :catch_162
    .catch Ljava/lang/Exception; {:try_start_15e .. :try_end_18e} :catch_190

    goto/16 :goto_b5

    .line 772
    .end local v3  # "mightBeGamestop":Z
    :catch_190
    move-exception v7

    goto/16 :goto_b5

    .line 786
    .restart local v5  # "name":Ljava/lang/String;
    :cond_193
    iget v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    const/16 v8, 0xb

    if-eq v7, v8, :cond_10d

    invoke-static {v4}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$500(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Landroid/view/InputDevice;

    move-result-object v7

    invoke-virtual {v7}, Landroid/view/InputDevice;->getName()Ljava/lang/String;

    move-result-object v7

    const-string v8, "Amazon"

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_10d

    .line 787
    const/16 v7, 0xb

    iput v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    .line 788
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v8

    iput-wide v8, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->lastConnect:J

    .line 789
    sget-object v7, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v8, "Setting GamepadType to Amazon Remote"

    invoke-virtual {v7, v8}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    goto/16 :goto_10d

    .line 801
    .end local v5  # "name":Ljava/lang/String;
    .restart local v0  # "bPS3Flipped":Z
    :pswitch_1bc  #0x60
    iget-boolean v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->is360:Z

    if-eqz v7, :cond_1c3

    const/4 v1, 0x1

    :goto_1c1
    goto/16 :goto_111

    :cond_1c3
    if-eqz v0, :cond_1c7

    const/4 v1, 0x4

    goto :goto_1c1

    :cond_1c7
    const/4 v1, 0x1

    goto :goto_1c1

    .line 802
    :pswitch_1c9  #0x63
    iget-boolean v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->is360:Z

    if-eqz v7, :cond_1d0

    const/4 v1, 0x4

    :goto_1ce
    goto/16 :goto_111

    :cond_1d0
    if-eqz v0, :cond_1d4

    const/4 v1, 0x1

    goto :goto_1ce

    :cond_1d4
    const/4 v1, 0x4

    goto :goto_1ce

    .line 803
    :pswitch_1d6  #0x64
    iget-boolean v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->is360:Z

    if-eqz v7, :cond_1de

    const/16 v1, 0x8

    :goto_1dc
    goto/16 :goto_111

    :cond_1de
    if-eqz v0, :cond_1e2

    const/4 v1, 0x2

    goto :goto_1dc

    :cond_1e2
    const/16 v1, 0x8

    goto :goto_1dc

    .line 804
    :pswitch_1e5  #0x61
    iget-boolean v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->is360:Z

    if-eqz v7, :cond_1ec

    const/4 v1, 0x2

    :goto_1ea
    goto/16 :goto_111

    :cond_1ec
    if-eqz v0, :cond_1f1

    const/16 v1, 0x8

    goto :goto_1ea

    :cond_1f1
    const/4 v1, 0x2

    goto :goto_1ea

    .line 806
    :pswitch_1f3  #0x6c
    const/16 v1, 0x10

    goto/16 :goto_111

    .line 807
    :pswitch_1f7  #0x6d
    const/16 v1, 0x20

    goto/16 :goto_111

    .line 808
    :pswitch_1fb  #0x67
    const/16 v1, 0x80

    goto/16 :goto_111

    .line 809
    :pswitch_1ff  #0x66
    const/16 v1, 0x40

    goto/16 :goto_111

    .line 810
    :pswitch_203  #0x6a
    const/16 v1, 0x1000

    goto/16 :goto_111

    .line 811
    :pswitch_207  #0x6b
    const/16 v1, 0x2000

    goto/16 :goto_111

    .line 814
    :pswitch_20b  #0x68
    iget-object v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    const/4 v8, 0x4

    const/high16 v9, 0x3f800000  # 1.0f

    aput v9, v7, v8

    goto/16 :goto_111

    .line 815
    :pswitch_214  #0x69
    iget-object v7, v4, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    const/4 v8, 0x5

    const/high16 v9, 0x3f800000  # 1.0f

    aput v9, v7, v8

    goto/16 :goto_111

    .line 820
    :pswitch_21d  #0x15
    const/16 v1, 0x400

    goto/16 :goto_11c

    .line 821
    :pswitch_221  #0x16
    const/16 v1, 0x800

    goto/16 :goto_11c

    .line 822
    :pswitch_225  #0x13
    const/16 v1, 0x100

    goto/16 :goto_11c

    .line 823
    :pswitch_229  #0x14
    const/16 v1, 0x200

    goto/16 :goto_11c

    .line 824
    :pswitch_22d  #0x17
    const/4 v1, 0x1

    goto/16 :goto_11c

    .line 833
    :sswitch_230
    const/16 v1, 0x400

    goto/16 :goto_131

    .line 834
    :sswitch_234
    const/16 v1, 0x800

    goto/16 :goto_131

    .line 835
    :sswitch_238
    const/16 v1, 0x100

    goto/16 :goto_131

    .line 836
    :sswitch_23c
    const/16 v1, 0x200

    goto/16 :goto_131

    .line 837
    :sswitch_240
    const/4 v1, 0x1

    goto/16 :goto_131

    .line 839
    :sswitch_243
    const/4 v1, 0x2

    .line 840
    invoke-virtual {p2}, Landroid/view/KeyEvent;->getScanCode()I

    move-result v7

    const/16 v8, 0x9e

    if-ne v7, v8, :cond_131

    or-int/lit16 v1, v1, 0x4000

    goto/16 :goto_131

    .line 844
    :sswitch_250
    const/16 v1, 0x1000

    .line 845
    invoke-virtual {p2}, Landroid/view/KeyEvent;->getScanCode()I

    move-result v7

    const/16 v8, 0xe2

    if-ne v7, v8, :cond_131

    const v7, 0x8000

    or-int/2addr v1, v7

    goto/16 :goto_131

    .line 847
    :sswitch_260
    const/16 v1, 0x2000

    goto/16 :goto_131

    .line 857
    :cond_264
    const/16 v7, 0x42

    if-ne p1, v7, :cond_13e

    .line 858
    or-int/lit8 v1, v1, 0x10

    .line 859
    const/16 p1, 0x6c

    goto/16 :goto_13e

    .line 799
    :pswitch_data_26e
    .packed-switch 0x60
        :pswitch_1bc  #00000060
        :pswitch_1e5  #00000061
        :pswitch_111  #00000062
        :pswitch_1c9  #00000063
        :pswitch_1d6  #00000064
        :pswitch_111  #00000065
        :pswitch_1ff  #00000066
        :pswitch_1fb  #00000067
        :pswitch_20b  #00000068
        :pswitch_214  #00000069
        :pswitch_203  #0000006a
        :pswitch_207  #0000006b
        :pswitch_1f3  #0000006c
        :pswitch_1f7  #0000006d
    .end packed-switch

    .line 819
    :pswitch_data_28e
    .packed-switch 0x13
        :pswitch_225  #00000013
        :pswitch_229  #00000014
        :pswitch_21d  #00000015
        :pswitch_221  #00000016
        :pswitch_22d  #00000017
    .end packed-switch

    .line 832
    :sswitch_data_29c
    .sparse-switch
        0x4 -> :sswitch_243
        0x13 -> :sswitch_238
        0x14 -> :sswitch_23c
        0x15 -> :sswitch_230
        0x16 -> :sswitch_234
        0x17 -> :sswitch_240
        0x52 -> :sswitch_250
        0x54 -> :sswitch_260
    .end sparse-switch
.end method

.method public onKeyEvent(Lcom/bda/controller/KeyEvent;)V
    .registers 12
    .param p1, "event"  # Lcom/bda/controller/KeyEvent;

    .prologue
    const/4 v9, 0x5

    const/high16 v8, 0x3f800000  # 1.0f

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x7

    .line 1077
    const/4 v0, 0x0

    .line 1078
    .local v0, "buttonMask":I
    invoke-virtual {p1}, Lcom/bda/controller/KeyEvent;->getControllerId()I

    move-result v3

    const/16 v4, 0x10

    invoke-virtual {p0, v3, v4}, Lcom/wardrumstudios/utils/WarGamepad;->GetDeviceIndex(II)I

    move-result v1

    .line 1079
    .local v1, "index":I
    const/4 v3, -0x1

    if-ne v1, v3, :cond_15

    .line 1158
    :cond_14
    :goto_14
    return-void

    .line 1080
    :cond_15
    iget-object v3, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v2, v3, v1

    .line 1083
    .local v2, "myGamePad":Lcom/wardrumstudios/utils/WarGamepad$GamePad;
    iget v3, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    if-eq v3, v6, :cond_27

    iget v3, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    if-eq v3, v5, :cond_27

    .line 1084
    invoke-virtual {p0, v1}, Lcom/wardrumstudios/utils/WarGamepad;->GetMogaControllerType(I)I

    move-result v3

    iput v3, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    .line 1090
    :cond_27
    invoke-virtual {p1}, Lcom/bda/controller/KeyEvent;->getAction()I

    move-result v3

    if-nez v3, :cond_b8

    .line 1091
    invoke-virtual {p1}, Lcom/bda/controller/KeyEvent;->getKeyCode()I

    move-result v3

    sparse-switch v3, :sswitch_data_126

    .line 1116
    sget-object v3, Ljava/lang/System;->out:Ljava/io/PrintStream;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "onKeyEvent "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {p1}, Lcom/bda/controller/KeyEvent;->getKeyCode()I

    move-result v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    .line 1119
    :cond_50
    :goto_50
    sget-object v3, Ljava/lang/System;->out:Ljava/io/PrintStream;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "onKeyEvent "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {p1}, Lcom/bda/controller/KeyEvent;->getKeyCode()I

    move-result v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    .line 1120
    if-eqz v0, :cond_14

    .line 1121
    iget v3, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    or-int/2addr v3, v0

    iput v3, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    goto :goto_14

    .line 1094
    :sswitch_74
    or-int/lit8 v0, v0, 0x1

    goto :goto_50

    .line 1095
    :sswitch_77
    or-int/lit8 v0, v0, 0x4

    goto :goto_50

    .line 1096
    :sswitch_7a
    or-int/lit8 v0, v0, 0x8

    goto :goto_50

    .line 1097
    :sswitch_7d
    or-int/lit8 v0, v0, 0x2

    goto :goto_50

    .line 1098
    :sswitch_80
    or-int/lit8 v0, v0, 0x10

    goto :goto_50

    .line 1099
    :sswitch_83
    or-int/lit8 v0, v0, 0x20

    goto :goto_50

    .line 1100
    :sswitch_86
    or-int/lit16 v0, v0, 0x80

    goto :goto_50

    .line 1101
    :sswitch_89
    or-int/lit8 v0, v0, 0x40

    goto :goto_50

    .line 1102
    :sswitch_8c
    or-int/lit16 v0, v0, 0x1000

    goto :goto_50

    .line 1103
    :sswitch_8f
    or-int/lit16 v0, v0, 0x2000

    goto :goto_50

    .line 1106
    :sswitch_92
    iget v3, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    if-ne v3, v5, :cond_50

    or-int/lit16 v0, v0, 0x100

    goto :goto_50

    .line 1107
    :sswitch_99
    iget v3, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    if-ne v3, v5, :cond_50

    or-int/lit16 v0, v0, 0x200

    goto :goto_50

    .line 1108
    :sswitch_a0
    iget v3, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    if-ne v3, v5, :cond_50

    or-int/lit16 v0, v0, 0x400

    goto :goto_50

    .line 1109
    :sswitch_a7
    iget v3, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    if-ne v3, v5, :cond_50

    or-int/lit16 v0, v0, 0x800

    goto :goto_50

    .line 1112
    :sswitch_ae
    iget-object v3, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    aput v8, v3, v6

    goto :goto_50

    .line 1113
    :sswitch_b3
    iget-object v3, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    aput v8, v3, v9

    goto :goto_50

    .line 1123
    :cond_b8
    invoke-virtual {p1}, Lcom/bda/controller/KeyEvent;->getKeyCode()I

    move-result v3

    sparse-switch v3, :sswitch_data_168

    .line 1148
    sget-object v3, Ljava/lang/System;->out:Ljava/io/PrintStream;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "onKeyEvent "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    .line 1152
    :cond_d7
    :goto_d7
    if-eqz v0, :cond_14

    .line 1153
    iget v3, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    xor-int/lit8 v4, v0, -0x1

    and-int/2addr v3, v4

    iput v3, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    goto/16 :goto_14

    .line 1126
    :sswitch_e2
    or-int/lit8 v0, v0, 0x1

    goto :goto_d7

    .line 1127
    :sswitch_e5
    or-int/lit8 v0, v0, 0x4

    goto :goto_d7

    .line 1128
    :sswitch_e8
    or-int/lit8 v0, v0, 0x8

    goto :goto_d7

    .line 1129
    :sswitch_eb
    or-int/lit8 v0, v0, 0x2

    goto :goto_d7

    .line 1130
    :sswitch_ee
    or-int/lit8 v0, v0, 0x10

    goto :goto_d7

    .line 1131
    :sswitch_f1
    or-int/lit8 v0, v0, 0x20

    goto :goto_d7

    .line 1132
    :sswitch_f4
    or-int/lit16 v0, v0, 0x80

    goto :goto_d7

    .line 1133
    :sswitch_f7
    or-int/lit8 v0, v0, 0x40

    goto :goto_d7

    .line 1134
    :sswitch_fa
    or-int/lit16 v0, v0, 0x1000

    goto :goto_d7

    .line 1135
    :sswitch_fd
    or-int/lit16 v0, v0, 0x2000

    goto :goto_d7

    .line 1138
    :sswitch_100
    iget v3, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    if-ne v3, v5, :cond_d7

    or-int/lit16 v0, v0, 0x100

    goto :goto_d7

    .line 1139
    :sswitch_107
    iget v3, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    if-ne v3, v5, :cond_d7

    or-int/lit16 v0, v0, 0x200

    goto :goto_d7

    .line 1140
    :sswitch_10e
    iget v3, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    if-ne v3, v5, :cond_d7

    or-int/lit16 v0, v0, 0x400

    goto :goto_d7

    .line 1141
    :sswitch_115
    iget v3, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    if-ne v3, v5, :cond_d7

    or-int/lit16 v0, v0, 0x800

    goto :goto_d7

    .line 1144
    :sswitch_11c
    iget-object v3, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    aput v7, v3, v6

    goto :goto_d7

    .line 1145
    :sswitch_121
    iget-object v3, v2, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    aput v7, v3, v9

    goto :goto_d7

    .line 1091
    :sswitch_data_126
    .sparse-switch
        0x13 -> :sswitch_92
        0x14 -> :sswitch_99
        0x15 -> :sswitch_a0
        0x16 -> :sswitch_a7
        0x60 -> :sswitch_74
        0x61 -> :sswitch_7d
        0x63 -> :sswitch_77
        0x64 -> :sswitch_7a
        0x66 -> :sswitch_89
        0x67 -> :sswitch_86
        0x68 -> :sswitch_ae
        0x69 -> :sswitch_b3
        0x6a -> :sswitch_8c
        0x6b -> :sswitch_8f
        0x6c -> :sswitch_80
        0x6d -> :sswitch_83
    .end sparse-switch

    .line 1123
    :sswitch_data_168
    .sparse-switch
        0x13 -> :sswitch_100
        0x14 -> :sswitch_107
        0x15 -> :sswitch_10e
        0x16 -> :sswitch_115
        0x60 -> :sswitch_e2
        0x61 -> :sswitch_eb
        0x63 -> :sswitch_e5
        0x64 -> :sswitch_e8
        0x66 -> :sswitch_f7
        0x67 -> :sswitch_f4
        0x68 -> :sswitch_11c
        0x69 -> :sswitch_121
        0x6a -> :sswitch_fa
        0x6b -> :sswitch_fd
        0x6c -> :sswitch_ee
        0x6d -> :sswitch_f1
    .end sparse-switch
.end method

.method public onKeyUp(ILandroid/view/KeyEvent;)Z
    .registers 15
    .param p1, "keyCode"  # I
    .param p2, "keyEvent"  # Landroid/view/KeyEvent;

    .prologue
    const/16 v7, 0x8

    const/4 v8, 0x2

    const/4 v11, -0x1

    const/4 v6, 0x4

    const/4 v5, 0x1

    .line 644
    invoke-virtual {p2}, Landroid/view/KeyEvent;->getDeviceId()I

    move-result v9

    invoke-virtual {p2}, Landroid/view/KeyEvent;->getSource()I

    move-result v10

    invoke-virtual {p0, v9, v10}, Lcom/wardrumstudios/utils/WarGamepad;->GetDeviceIndex(II)I

    move-result v2

    .line 645
    .local v2, "index":I
    if-ne v2, v11, :cond_53

    .line 646
    invoke-virtual {p2}, Landroid/view/KeyEvent;->getDevice()Landroid/view/InputDevice;

    move-result-object v9

    if-eqz v9, :cond_51

    invoke-virtual {p2}, Landroid/view/KeyEvent;->getDevice()Landroid/view/InputDevice;

    move-result-object v9

    invoke-virtual {v9}, Landroid/view/InputDevice;->getSources()I

    move-result v4

    .line 647
    .local v4, "source":I
    :goto_22
    invoke-virtual {p2}, Landroid/view/KeyEvent;->getDeviceId()I

    move-result v9

    invoke-virtual {p0, v9, v4}, Lcom/wardrumstudios/utils/WarGamepad;->GetFreeIndex(II)I

    move-result v2

    .line 648
    if-ne v2, v11, :cond_53

    .line 649
    invoke-virtual {p2}, Landroid/view/KeyEvent;->getSource()I

    move-result v5

    and-int/lit8 v5, v5, 0x10

    if-eqz v5, :cond_4c

    .line 650
    sget-object v5, Ljava/lang/System;->out:Ljava/io/PrintStream;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "********************ERROR********* cannot assign controller keyEvent "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    .line 652
    :cond_4c
    invoke-super {p0, p1, p2}, Lcom/wardrumstudios/utils/WarBilling;->onKeyUp(ILandroid/view/KeyEvent;)Z

    move-result v5

    .line 731
    .end local v4  # "source":I
    :goto_50
    return v5

    .line 646
    :cond_51
    const/4 v4, 0x0

    goto :goto_22

    .line 655
    :cond_53
    iget-object v9, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v3, v9, v2

    .line 657
    .local v3, "myGamePad":Lcom/wardrumstudios/utils/WarGamepad$GamePad;
    const/4 v1, 0x0

    .line 659
    .local v1, "buttonMask":I
    const/4 v0, 0x1

    .line 661
    .local v0, "bPS3Flipped":Z
    packed-switch p1, :pswitch_data_134

    .line 679
    :goto_5c
    :pswitch_5c  #0x62, 0x65
    if-nez v1, :cond_6b

    invoke-static {v3}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$000(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Z

    move-result v6

    if-nez v6, :cond_6b

    .line 680
    packed-switch p1, :pswitch_data_154

    .line 687
    :goto_67
    if-eqz v1, :cond_6b

    iput v5, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadDpadHack:I

    .line 689
    :cond_6b
    if-nez v1, :cond_7a

    invoke-static {v3}, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->access$000(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)Z

    move-result v5

    if-eqz v5, :cond_7a

    iget v5, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    if-eq v5, v11, :cond_7a

    .line 690
    sparse-switch p1, :sswitch_data_162

    .line 711
    :cond_7a
    :goto_7a
    iget v5, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    const/4 v6, 0x3

    if-ne v5, v6, :cond_87

    .line 712
    const/16 v5, 0x6f

    if-ne p1, v5, :cond_12a

    .line 713
    or-int/lit8 v1, v1, 0x20

    .line 714
    const/16 p1, 0x6d

    .line 727
    :cond_87
    :goto_87
    if-eqz v1, :cond_90

    .line 728
    iget v5, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    xor-int/lit8 v6, v1, -0x1

    and-int/2addr v5, v6

    iput v5, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadButtonMask:I

    .line 731
    :cond_90
    invoke-super {p0, p1, p2}, Lcom/wardrumstudios/utils/WarBilling;->onKeyUp(ILandroid/view/KeyEvent;)Z

    move-result v5

    goto :goto_50

    .line 663
    :pswitch_95  #0x60
    iget-boolean v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->is360:Z

    if-eqz v7, :cond_9b

    move v1, v5

    :goto_9a
    goto :goto_5c

    :cond_9b
    if-eqz v0, :cond_9f

    move v1, v6

    goto :goto_9a

    :cond_9f
    move v1, v5

    goto :goto_9a

    .line 664
    :pswitch_a1  #0x63
    iget-boolean v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->is360:Z

    if-eqz v7, :cond_a7

    move v1, v6

    :goto_a6
    goto :goto_5c

    :cond_a7
    if-eqz v0, :cond_ab

    move v1, v5

    goto :goto_a6

    :cond_ab
    move v1, v6

    goto :goto_a6

    .line 665
    :pswitch_ad  #0x64
    iget-boolean v6, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->is360:Z

    if-eqz v6, :cond_b3

    move v1, v7

    :goto_b2
    goto :goto_5c

    :cond_b3
    if-eqz v0, :cond_b7

    move v1, v8

    goto :goto_b2

    :cond_b7
    move v1, v7

    goto :goto_b2

    .line 666
    :pswitch_b9  #0x61
    iget-boolean v6, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->is360:Z

    if-eqz v6, :cond_bf

    move v1, v8

    :goto_be
    goto :goto_5c

    :cond_bf
    if-eqz v0, :cond_c3

    move v1, v7

    goto :goto_be

    :cond_c3
    move v1, v8

    goto :goto_be

    .line 668
    :pswitch_c5  #0x6c
    const/16 v1, 0x10

    goto :goto_5c

    .line 669
    :pswitch_c8  #0x6d
    const/16 v1, 0x20

    goto :goto_5c

    .line 670
    :pswitch_cb  #0x67
    const/16 v1, 0x80

    goto :goto_5c

    .line 671
    :pswitch_ce  #0x66
    const/16 v1, 0x40

    goto :goto_5c

    .line 672
    :pswitch_d1  #0x6a
    const/16 v1, 0x1000

    goto :goto_5c

    .line 673
    :pswitch_d4  #0x6b
    const/16 v1, 0x2000

    goto :goto_5c

    .line 676
    :pswitch_d7  #0x68
    iget-object v7, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    const/4 v8, 0x0

    aput v8, v7, v6

    goto :goto_5c

    .line 677
    :pswitch_dd  #0x69
    iget-object v6, v3, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    const/4 v7, 0x5

    const/4 v8, 0x0

    aput v8, v6, v7

    goto/16 :goto_5c

    .line 681
    :pswitch_e5  #0x15
    const/16 v1, 0x400

    goto :goto_67

    .line 682
    :pswitch_e8  #0x16
    const/16 v1, 0x800

    goto/16 :goto_67

    .line 683
    :pswitch_ec  #0x13
    const/16 v1, 0x100

    goto/16 :goto_67

    .line 684
    :pswitch_f0  #0x14
    const/16 v1, 0x200

    goto/16 :goto_67

    .line 685
    :pswitch_f4  #0x17
    const/4 v1, 0x1

    goto/16 :goto_67

    .line 691
    :sswitch_f7
    const/16 v1, 0x400

    goto :goto_7a

    .line 692
    :sswitch_fa
    const/16 v1, 0x800

    goto/16 :goto_7a

    .line 693
    :sswitch_fe
    const/16 v1, 0x100

    goto/16 :goto_7a

    .line 694
    :sswitch_102
    const/16 v1, 0x200

    goto/16 :goto_7a

    .line 695
    :sswitch_106
    const/4 v1, 0x1

    goto/16 :goto_7a

    .line 697
    :sswitch_109
    const/4 v1, 0x2

    .line 698
    invoke-virtual {p2}, Landroid/view/KeyEvent;->getScanCode()I

    move-result v5

    const/16 v6, 0x9e

    if-ne v5, v6, :cond_7a

    or-int/lit16 v1, v1, 0x4000

    goto/16 :goto_7a

    .line 701
    :sswitch_116
    const/16 v1, 0x1000

    .line 702
    invoke-virtual {p2}, Landroid/view/KeyEvent;->getScanCode()I

    move-result v5

    const/16 v6, 0xe2

    if-ne v5, v6, :cond_7a

    const v5, 0x8000

    or-int/2addr v1, v5

    goto/16 :goto_7a

    .line 704
    :sswitch_126
    const/16 v1, 0x2000

    goto/16 :goto_7a

    .line 715
    :cond_12a
    const/16 v5, 0x42

    if-ne p1, v5, :cond_87

    .line 716
    or-int/lit8 v1, v1, 0x10

    .line 717
    const/16 p1, 0x6c

    goto/16 :goto_87

    .line 661
    :pswitch_data_134
    .packed-switch 0x60
        :pswitch_95  #00000060
        :pswitch_b9  #00000061
        :pswitch_5c  #00000062
        :pswitch_a1  #00000063
        :pswitch_ad  #00000064
        :pswitch_5c  #00000065
        :pswitch_ce  #00000066
        :pswitch_cb  #00000067
        :pswitch_d7  #00000068
        :pswitch_dd  #00000069
        :pswitch_d1  #0000006a
        :pswitch_d4  #0000006b
        :pswitch_c5  #0000006c
        :pswitch_c8  #0000006d
    .end packed-switch

    .line 680
    :pswitch_data_154
    .packed-switch 0x13
        :pswitch_ec  #00000013
        :pswitch_f0  #00000014
        :pswitch_e5  #00000015
        :pswitch_e8  #00000016
        :pswitch_f4  #00000017
    .end packed-switch

    .line 690
    :sswitch_data_162
    .sparse-switch
        0x4 -> :sswitch_109
        0x13 -> :sswitch_fe
        0x14 -> :sswitch_102
        0x15 -> :sswitch_f7
        0x16 -> :sswitch_fa
        0x17 -> :sswitch_106
        0x52 -> :sswitch_116
        0x54 -> :sswitch_126
    .end sparse-switch
.end method

.method public onMotionEvent(Lcom/bda/controller/MotionEvent;)V
    .registers 8
    .param p1, "event"  # Lcom/bda/controller/MotionEvent;

    .prologue
    const/4 v5, 0x1

    const/4 v4, 0x0

    .line 1169
    invoke-virtual {p1}, Lcom/bda/controller/MotionEvent;->getControllerId()I

    move-result v2

    const/16 v3, 0x10

    invoke-virtual {p0, v2, v3}, Lcom/wardrumstudios/utils/WarGamepad;->GetDeviceIndex(II)I

    move-result v0

    .line 1170
    .local v0, "index":I
    const/4 v2, -0x1

    if-ne v0, v2, :cond_10

    .line 1182
    :goto_f
    return-void

    .line 1171
    :cond_10
    iget-object v2, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v2, v0

    .line 1173
    .local v1, "myGamePad":Lcom/wardrumstudios/utils/WarGamepad$GamePad;
    iget v2, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    const/4 v3, 0x4

    if-eq v2, v3, :cond_24

    iget v2, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    const/4 v3, 0x7

    if-eq v2, v3, :cond_24

    .line 1174
    invoke-virtual {p0, v0}, Lcom/wardrumstudios/utils/WarGamepad;->GetMogaControllerType(I)I

    move-result v2

    iput v2, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    .line 1176
    :cond_24
    invoke-virtual {p1, v4}, Lcom/bda/controller/MotionEvent;->getAxisValue(I)F

    move-result v2

    invoke-virtual {p0, v2}, Lcom/wardrumstudios/utils/WarGamepad;->GetWithDeadZone(F)F

    move-result v2

    iput v2, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->mobiX:F

    .line 1177
    invoke-virtual {p1, v5}, Lcom/bda/controller/MotionEvent;->getAxisValue(I)F

    move-result v2

    invoke-virtual {p0, v2}, Lcom/wardrumstudios/utils/WarGamepad;->GetWithDeadZone(F)F

    move-result v2

    iput v2, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->mobiY:F

    .line 1178
    iget-object v2, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    iget v3, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->mobiX:F

    aput v3, v2, v4

    .line 1179
    iget-object v2, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    iget v3, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->mobiY:F

    aput v3, v2, v5

    .line 1180
    iget-object v2, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    const/4 v3, 0x2

    const/16 v4, 0xb

    invoke-virtual {p1, v4}, Lcom/bda/controller/MotionEvent;->getAxisValue(I)F

    move-result v4

    invoke-virtual {p0, v4}, Lcom/wardrumstudios/utils/WarGamepad;->GetWithDeadZone(F)F

    move-result v4

    aput v4, v2, v3

    .line 1181
    iget-object v2, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadAxes:[F

    const/4 v3, 0x3

    const/16 v4, 0xe

    invoke-virtual {p1, v4}, Lcom/bda/controller/MotionEvent;->getAxisValue(I)F

    move-result v4

    invoke-virtual {p0, v4}, Lcom/wardrumstudios/utils/WarGamepad;->GetWithDeadZone(F)F

    move-result v4

    aput v4, v2, v3

    goto :goto_f
.end method

.method public onStateEvent(Lcom/bda/controller/StateEvent;)V
    .registers 8
    .param p1, "event"  # Lcom/bda/controller/StateEvent;

    .prologue
    const/16 v5, 0x10

    const/4 v4, -0x1

    .line 1186
    invoke-virtual {p1}, Lcom/bda/controller/StateEvent;->getControllerId()I

    move-result v1

    invoke-virtual {p0, v1, v5}, Lcom/wardrumstudios/utils/WarGamepad;->GetDeviceIndex(II)I

    move-result v0

    .line 1189
    .local v0, "index":I
    sget-object v1, Ljava/lang/System;->out:Ljava/io/PrintStream;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "onStateEvent "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " getState "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p1}, Lcom/bda/controller/StateEvent;->getState()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " action "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p1}, Lcom/bda/controller/StateEvent;->getAction()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    .line 1190
    invoke-virtual {p1}, Lcom/bda/controller/StateEvent;->getState()I

    move-result v1

    packed-switch v1, :pswitch_data_7e

    .line 1222
    :cond_46
    :goto_46
    return-void

    .line 1192
    :pswitch_47  #0x1
    invoke-virtual {p1}, Lcom/bda/controller/StateEvent;->getAction()I

    move-result v1

    packed-switch v1, :pswitch_data_86

    goto :goto_46

    .line 1194
    :pswitch_4f  #0x0
    if-le v0, v4, :cond_46

    .line 1195
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, v0

    iput v4, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    .line 1196
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, v0

    const/4 v2, 0x0

    iput-boolean v2, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->active:Z

    goto :goto_46

    .line 1201
    :pswitch_5f  #0x1
    if-ne v0, v4, :cond_46

    .line 1202
    invoke-virtual {p1}, Lcom/bda/controller/StateEvent;->getControllerId()I

    move-result v1

    invoke-virtual {p0, v1, v5}, Lcom/wardrumstudios/utils/WarGamepad;->GetFreeIndex(II)I

    move-result v0

    .line 1203
    if-le v0, v4, :cond_46

    .line 1205
    iget-object v1, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v1, v1, v0

    invoke-virtual {p0, v0}, Lcom/wardrumstudios/utils/WarGamepad;->GetMogaControllerType(I)I

    move-result v2

    iput v2, v1, Lcom/wardrumstudios/utils/WarGamepad$GamePad;->GamepadType:I

    goto :goto_46

    .line 1215
    :pswitch_76  #0x2
    invoke-virtual {p1}, Lcom/bda/controller/StateEvent;->getAction()I

    move-result v1

    const/4 v2, 0x1

    if-ne v1, v2, :cond_46

    goto :goto_46

    .line 1190
    :pswitch_data_7e
    .packed-switch 0x1
        :pswitch_47  #00000001
        :pswitch_76  #00000002
    .end packed-switch

    .line 1192
    :pswitch_data_86
    .packed-switch 0x0
        :pswitch_4f  #00000000
        :pswitch_5f  #00000001
    .end packed-switch
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 16
    .param p1, "event"  # Landroid/view/MotionEvent;

    .prologue
    const/4 v12, 0x1

    const/4 v13, -0x1

    .line 946
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getDeviceId()I

    move-result v0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getSource()I

    move-result v1

    invoke-virtual {p0, v0, v1}, Lcom/wardrumstudios/utils/WarGamepad;->GetDeviceIndex(II)I

    move-result v7

    .line 947
    .local v7, "gIndex":I
    if-ne v7, v13, :cond_4f

    .line 948
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getDevice()Landroid/view/InputDevice;

    move-result-object v0

    if-eqz v0, :cond_4d

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getDevice()Landroid/view/InputDevice;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/InputDevice;->getSources()I

    move-result v11

    .line 949
    .local v11, "source":I
    :goto_1e
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getDeviceId()I

    move-result v0

    invoke-virtual {p0, v0, v11}, Lcom/wardrumstudios/utils/WarGamepad;->GetFreeIndex(II)I

    move-result v7

    .line 950
    if-ne v7, v13, :cond_4f

    .line 951
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getSource()I

    move-result v0

    and-int/lit8 v0, v0, 0x10

    if-eqz v0, :cond_48

    .line 952
    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v12, "********************ERROR********* cannot assign controller - onTouchEvent "

    invoke-virtual {v1, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    .line 954
    :cond_48
    invoke-super {p0, p1}, Lcom/wardrumstudios/utils/WarBilling;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result v0

    .line 991
    .end local v11  # "source":I
    :goto_4c
    return v0

    .line 948
    :cond_4d
    const/4 v11, 0x0

    goto :goto_1e

    .line 958
    :cond_4f
    iget-object v0, p0, Lcom/wardrumstudios/utils/WarGamepad;->GamePads:[Lcom/wardrumstudios/utils/WarGamepad$GamePad;

    aget-object v0, v0, v7

    invoke-direct {p0, v0}, Lcom/wardrumstudios/utils/WarGamepad;->ClearBadJoystickAxis(Lcom/wardrumstudios/utils/WarGamepad$GamePad;)V

    .line 959
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x9

    if-lt v0, v1, :cond_9f

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getSource()I

    move-result v0

    const v1, 0x100008

    if-ne v0, v1, :cond_9f

    .line 960
    const/4 v2, 0x0

    .line 961
    .local v2, "count":I
    const/4 v3, 0x0

    .local v3, "x1":I
    const/4 v4, 0x0

    .local v4, "y1":I
    const/4 v5, 0x0

    .local v5, "x2":I
    const/4 v6, 0x0

    .line 963
    .local v6, "y2":I
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getPointerCount()I

    move-result v10

    .line 964
    .local v10, "numEvents":I
    const/4 v8, 0x0

    .local v8, "i":I
    :goto_6f
    if-ge v8, v10, :cond_95

    .line 967
    invoke-virtual {p1, v8}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v9

    .line 971
    .local v9, "index":I
    if-nez v2, :cond_86

    .line 973
    invoke-virtual {p1, v8}, Landroid/view/MotionEvent;->getX(I)F

    move-result v0

    float-to-int v3, v0

    .line 974
    invoke-virtual {p1, v8}, Landroid/view/MotionEvent;->getY(I)F

    move-result v0

    float-to-int v4, v0

    .line 975
    add-int/lit8 v2, v2, 0x1

    .line 964
    :cond_83
    :goto_83
    add-int/lit8 v8, v8, 0x1

    goto :goto_6f

    .line 977
    :cond_86
    if-ne v2, v12, :cond_83

    .line 979
    invoke-virtual {p1, v8}, Landroid/view/MotionEvent;->getX(I)F

    move-result v0

    float-to-int v5, v0

    .line 980
    invoke-virtual {p1, v8}, Landroid/view/MotionEvent;->getY(I)F

    move-result v0

    float-to-int v6, v0

    .line 981
    add-int/lit8 v2, v2, 0x1

    goto :goto_83

    .line 986
    .end local v9  # "index":I
    :cond_95
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v1

    move-object v0, p0

    invoke-virtual/range {v0 .. v6}, Lcom/wardrumstudios/utils/WarGamepad;->TouchpadEvent(IIIIII)V

    move v0, v12

    .line 988
    goto :goto_4c

    .line 991
    .end local v2  # "count":I
    .end local v3  # "x1":I
    .end local v4  # "y1":I
    .end local v5  # "x2":I
    .end local v6  # "y2":I
    .end local v8  # "i":I
    .end local v10  # "numEvents":I
    :cond_9f
    invoke-super {p0, p1}, Lcom/wardrumstudios/utils/WarBilling;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result v0

    goto :goto_4c
.end method

.method public native processTouchpadAsPointer(Landroid/view/ViewParent;Z)Z
.end method
