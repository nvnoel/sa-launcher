.class public Lcom/fastman92/main_activity_launcher/Settings;
.super Ljava/lang/Object;
.source "Settings.java"


# static fields
.field public static AndroidDATAdirectory:Ljava/lang/String;

.field public static AndroidDirectory:Ljava/lang/String;

.field public static AndroidOBBdirectory:Ljava/lang/String;

.field public static ExternalStorageDirectory:Ljava/lang/String;

.field public static OBB_PATH_PREFIX:Ljava/lang/String;

.field public static final apkModifierCompileDateTime:Ljava/lang/String;

.field public static bSettingsLoaded:Z

.field public static originalPackageName:Ljava/lang/String;

.field public static showMessageBoxBeforeStartingApplication:Z


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 10
    const/4 v0, 0x0

    sput-boolean v0, Lcom/fastman92/main_activity_launcher/Settings;->bSettingsLoaded:Z

    .line 12
    sget-object v0, Lcom/fastman92/main_activity_launcher/SettingsGenerated;->apkModifierCompileDateTime:Ljava/lang/String;

    sput-object v0, Lcom/fastman92/main_activity_launcher/Settings;->apkModifierCompileDateTime:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static getAssetPacksDir(Landroid/content/Context;)Ljava/io/File;
    .registers 3
    .param p0, "context"  # Landroid/content/Context;

    .line 77
    invoke-virtual {p0}, Landroid/content/Context;->getObbDir()Ljava/io/File;

    move-result-object v0

    invoke-static {v0}, Lcom/fastman92/main_activity_launcher/Functions;->AndroidAssetPacksDirToUnprotected(Ljava/io/File;)Ljava/io/File;

    move-result-object v0

    .line 79
    .local v0, "dir_unprotected":Ljava/io/File;
    if-nez v0, :cond_c

    .line 80
    const/4 v1, 0x0

    return-object v1

    .line 82
    :cond_c
    return-object v0
.end method

.method public static getExternalFilesDir(Landroid/content/Context;)Ljava/io/File;
    .registers 2
    .param p0, "context"  # Landroid/content/Context;

    .line 52
    const/4 v0, 0x0

    invoke-static {p0, v0}, Lcom/fastman92/main_activity_launcher/Settings;->getExternalFilesDir(Landroid/content/Context;Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    return-object v0
.end method

.method public static getExternalFilesDir(Landroid/content/Context;Ljava/lang/String;)Ljava/io/File;
    .registers 4
    .param p0, "context"  # Landroid/content/Context;
    .param p1, "type"  # Ljava/lang/String;

    .line 40
    invoke-virtual {p0, p1}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    invoke-static {v0}, Lcom/fastman92/main_activity_launcher/Functions;->AndroidDATAdirToUnprotected(Ljava/io/File;)Ljava/io/File;

    move-result-object v0

    .line 42
    .local v0, "dir_unprotected":Ljava/io/File;
    if-nez v0, :cond_c

    .line 43
    const/4 v1, 0x0

    return-object v1

    .line 45
    :cond_c
    invoke-static {v0}, Lcom/fastman92/main_activity_launcher/Functions;->MkDirIfDoesNotExist(Ljava/io/File;)V

    .line 47
    return-object v0
.end method

.method public static getExternalFilesDirs(Landroid/content/Context;Ljava/lang/String;)[Ljava/io/File;
    .registers 5
    .param p0, "context"  # Landroid/content/Context;
    .param p1, "type"  # Ljava/lang/String;

    .line 56
    invoke-virtual {p0, p1}, Landroid/content/Context;->getExternalFilesDirs(Ljava/lang/String;)[Ljava/io/File;

    move-result-object v0

    .line 58
    .local v0, "array":[Ljava/io/File;
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_5
    array-length v2, v0

    if-ge v1, v2, :cond_13

    .line 59
    aget-object v2, v0, v1

    invoke-static {v2}, Lcom/fastman92/main_activity_launcher/Functions;->AndroidDATAdirToUnprotected(Ljava/io/File;)Ljava/io/File;

    move-result-object v2

    aput-object v2, v0, v1

    .line 58
    add-int/lit8 v1, v1, 0x1

    goto :goto_5

    .line 61
    .end local v1  # "i":I
    :cond_13
    return-object v0
.end method

.method public static getObbDir(Landroid/content/Context;)Ljava/io/File;
    .registers 3
    .param p0, "context"  # Landroid/content/Context;

    .line 65
    invoke-virtual {p0}, Landroid/content/Context;->getObbDir()Ljava/io/File;

    move-result-object v0

    invoke-static {v0}, Lcom/fastman92/main_activity_launcher/Functions;->AndroidOBBdirToUnprotected(Ljava/io/File;)Ljava/io/File;

    move-result-object v0

    .line 67
    .local v0, "dir_unprotected":Ljava/io/File;
    if-nez v0, :cond_c

    .line 68
    const/4 v1, 0x0

    return-object v1

    .line 70
    :cond_c
    invoke-static {v0}, Lcom/fastman92/main_activity_launcher/Functions;->MkDirIfDoesNotExist(Ljava/io/File;)V

    .line 72
    return-object v0
.end method

.method public static getObbDirs(Landroid/content/Context;)[Ljava/io/File;
    .registers 4
    .param p0, "context"  # Landroid/content/Context;

    .line 86
    invoke-virtual {p0}, Landroid/content/Context;->getObbDirs()[Ljava/io/File;

    move-result-object v0

    .line 88
    .local v0, "array":[Ljava/io/File;
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_5
    array-length v2, v0

    if-ge v1, v2, :cond_13

    .line 89
    aget-object v2, v0, v1

    invoke-static {v2}, Lcom/fastman92/main_activity_launcher/Functions;->AndroidOBBdirToUnprotected(Ljava/io/File;)Ljava/io/File;

    move-result-object v2

    aput-object v2, v0, v1

    .line 88
    add-int/lit8 v1, v1, 0x1

    goto :goto_5

    .line 91
    .end local v1  # "i":I
    :cond_13
    return-object v0
.end method
