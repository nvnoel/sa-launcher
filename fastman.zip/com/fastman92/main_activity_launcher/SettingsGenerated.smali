.class public Lcom/fastman92/main_activity_launcher/SettingsGenerated;
.super Ljava/lang/Object;
.source "SettingsGenerated.java"


# static fields
.field public static final apkModifierCompileDateTime:Ljava/lang/String; = "Sat, 12 Oct 2024 08:23:34 GMT"

.field public static final apkModifierCompileTimestamp:J = 0x8dcea9729c5eb4cL

.field public static final packageName:Ljava/lang/String; = "com.rockstargames.gtasa"


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
