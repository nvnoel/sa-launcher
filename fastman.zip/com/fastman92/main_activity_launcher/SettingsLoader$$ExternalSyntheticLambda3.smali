.class public final synthetic Lcom/fastman92/main_activity_launcher/SettingsLoader$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lcom/fastman92/main_activity_launcher/SettingsLoader$OnRequestPermissions;


# instance fields
.field public final synthetic f$0:Lcom/fastman92/main_activity_launcher/SettingsLoader;


# direct methods
.method public synthetic constructor <init>(Lcom/fastman92/main_activity_launcher/SettingsLoader;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fastman92/main_activity_launcher/SettingsLoader$$ExternalSyntheticLambda3;->f$0:Lcom/fastman92/main_activity_launcher/SettingsLoader;

    return-void
.end method


# virtual methods
.method public final onRequestPermissions()V
    .registers 2

    iget-object v0, p0, Lcom/fastman92/main_activity_launcher/SettingsLoader$$ExternalSyntheticLambda3;->f$0:Lcom/fastman92/main_activity_launcher/SettingsLoader;

    invoke-virtual {v0}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->lambda$onCreate$2$com-fastman92-main_activity_launcher-SettingsLoader()V

    return-void
.end method
