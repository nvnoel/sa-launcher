.class public Lcom/fastman92/main_activity_launcher/Application;
.super Lcom/fastman92/main_activity_launcher/ApplicationOriginal;
.source "Application.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 10
    invoke-direct {p0}, Lcom/fastman92/main_activity_launcher/ApplicationOriginal;-><init>()V

    return-void
.end method


# virtual methods
.method HandleException(Ljava/lang/Exception;)V
    .registers 3
    .param p1, "e"  # Ljava/lang/Exception;

    .line 27
    invoke-virtual {p1}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/fastman92/main_activity_launcher/Application;->ShowErrorMessage(Ljava/lang/String;)V

    .line 28
    return-void
.end method

.method ShowErrorMessage(Ljava/lang/String;)V
    .registers 3
    .param p1, "msg"  # Ljava/lang/String;

    .line 33
    const-string v0, "fastman92 app launcher"

    invoke-static {v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 35
    const/4 v0, 0x1

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    .line 36
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 37
    return-void
.end method

.method public onCreate()V
    .registers 3

    .line 13
    invoke-static {p0}, Lcom/fastman92/main_activity_launcher/Functions;->CodeOnApplicationLaunch(Landroid/content/Context;)V

    .line 16
    const/4 v0, 0x0

    :try_start_4
    invoke-static {p0, v0}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->InitializeSettings(Landroid/content/Context;Z)V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_7} :catch_8

    .line 20
    goto :goto_15

    .line 17
    :catch_8
    move-exception v0

    .line 18
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->SetErrorMessage(Ljava/lang/String;)V

    .line 19
    sget-object v1, Lcom/fastman92/main_activity_launcher/SettingsLoader;->errorMessage:Ljava/lang/String;

    invoke-virtual {p0, v1}, Lcom/fastman92/main_activity_launcher/Application;->ShowErrorMessage(Ljava/lang/String;)V

    .line 22
    .end local v0  # "e":Ljava/lang/Exception;
    :goto_15
    invoke-super {p0}, Lcom/fastman92/main_activity_launcher/ApplicationOriginal;->onCreate()V

    .line 23
    return-void
.end method
