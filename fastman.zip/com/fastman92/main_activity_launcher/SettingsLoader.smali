.class public Lcom/fastman92/main_activity_launcher/SettingsLoader;
.super Landroid/app/Activity;
.source "SettingsLoader.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/fastman92/main_activity_launcher/SettingsLoader$OnRequestPermissions;
    }
.end annotation


# static fields
.field private static final REQUEST_MANAGE_EXTERNAL_STORAGE_PERMISSION:I = 0x65

.field private static final REQUEST_WRITE_EXTERNAL_STORAGE_PERMISSION:I = 0x64

.field public static XMLsettingsFilePath:Ljava/lang/String; = null

.field private static bCheckForMultipleDirs:Z = false

.field static context:Landroid/content/Context; = null

.field public static errorMessage:Ljava/lang/String; = null

.field private static final launcherPropertyPrefix:Ljava/lang/String; = "LAUNCHER_"

.field private static final settingsAll:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static settingsInitializationAttemptedInActivity:Z

.field private static final settingsStoredInFile:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public static useLauncherSettingsXml:Z


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 45
    const/4 v0, 0x0

    sput-boolean v0, Lcom/fastman92/main_activity_launcher/SettingsLoader;->settingsInitializationAttemptedInActivity:Z

    .line 47
    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    sput-object v1, Lcom/fastman92/main_activity_launcher/SettingsLoader;->settingsStoredInFile:Ljava/util/HashMap;

    .line 48
    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    sput-object v1, Lcom/fastman92/main_activity_launcher/SettingsLoader;->settingsAll:Ljava/util/HashMap;

    .line 50
    sput-boolean v0, Lcom/fastman92/main_activity_launcher/SettingsLoader;->bCheckForMultipleDirs:Z

    .line 58
    const/4 v0, 0x0

    sput-object v0, Lcom/fastman92/main_activity_launcher/SettingsLoader;->errorMessage:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 43
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method private static CheckIfDirectoriesExist([Ljava/io/File;ZZ)V
    .registers 7
    .param p0, "dirs"  # [Ljava/io/File;
    .param p1, "bCreateNoMedia"  # Z
    .param p2, "bCreateReadmeInAndroidUnprotected"  # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 515
    array-length v0, p0

    const/4 v1, 0x0

    :goto_2
    if-ge v1, v0, :cond_11

    aget-object v2, p0, v1

    .line 517
    .local v2, "dir":Ljava/io/File;
    invoke-static {v2, p1, p2}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->CheckIfDirectoryExists(Ljava/io/File;ZZ)V

    .line 519
    sget-boolean v3, Lcom/fastman92/main_activity_launcher/SettingsLoader;->bCheckForMultipleDirs:Z

    if-nez v3, :cond_e

    .line 520
    goto :goto_11

    .line 515
    .end local v2  # "dir":Ljava/io/File;
    :cond_e
    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    .line 522
    :cond_11
    :goto_11
    return-void
.end method

.method private static CheckIfDirectoryExists(Ljava/io/File;ZZ)V
    .registers 11
    .param p0, "dir"  # Ljava/io/File;
    .param p1, "bCreateNoMedia"  # Z
    .param p2, "bCreateReadmeInAndroidUnprotected"  # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 525
    invoke-static {p0}, Lcom/fastman92/main_activity_launcher/Functions;->MkDirIfDoesNotExist(Ljava/io/File;)V

    .line 527
    invoke-virtual {p0}, Ljava/io/File;->exists()Z

    move-result v0

    if-eqz v0, :cond_4c

    .line 528
    if-eqz p1, :cond_49

    .line 529
    sget-object v0, Lcom/fastman92/main_activity_launcher/Functions;->getPathToDirectoryInsideAndroidFromAndroidDir_pattern:Ljava/util/regex/Pattern;

    invoke-virtual {p0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v0

    .line 531
    .local v0, "m":Ljava/util/regex/Matcher;
    invoke-virtual {v0}, Ljava/util/regex/Matcher;->find()Z

    move-result v1

    if-eqz v1, :cond_49

    .line 532
    invoke-virtual {v0}, Ljava/util/regex/Matcher;->group()Ljava/lang/String;

    move-result-object v1

    .line 534
    .local v1, "dirPath":Ljava/lang/String;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    sget-object v3, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ".nomedia"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 536
    .local v2, "noMediaPath":Ljava/lang/String;
    new-instance v3, Ljava/io/File;

    invoke-direct {v3, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 538
    .local v3, "file":Ljava/io/File;
    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    move-result v4

    if-nez v4, :cond_49

    .line 540
    :try_start_43
    invoke-virtual {v3}, Ljava/io/File;->createNewFile()Z
    :try_end_46
    .catch Ljava/lang/Exception; {:try_start_43 .. :try_end_46} :catch_47

    .line 542
    :goto_46
    goto :goto_49

    :catch_47
    move-exception v4

    goto :goto_46

    .line 547
    .end local v0  # "m":Ljava/util/regex/Matcher;
    .end local v1  # "dirPath":Ljava/lang/String;
    .end local v2  # "noMediaPath":Ljava/lang/String;
    .end local v3  # "file":Ljava/io/File;
    :cond_49
    :goto_49
    if-nez p2, :cond_4c

    .line 548
    return-void

    .line 551
    :cond_4c
    new-instance v0, Ljava/io/File;

    invoke-virtual {p0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/fastman92/main_activity_launcher/Functions;->getPathToAndroidUnprotectedDir(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 553
    .local v0, "AndroidDir":Ljava/io/File;
    invoke-static {v0}, Lcom/fastman92/main_activity_launcher/Functions;->MkDirIfDoesNotExist(Ljava/io/File;)V

    .line 555
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_fc

    .line 561
    if-eqz p2, :cond_df

    sget-object v1, Lcom/fastman92/main_activity_launcher/Settings;->AndroidDirectory:Ljava/lang/String;

    const-string v2, "Android_unprotected"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_df

    .line 563
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    sget-object v2, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "About.txt"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 565
    .local v1, "promoPath":Ljava/lang/String;
    const-wide/16 v2, 0x0

    .line 567
    .local v2, "timestampInAboutFile":J
    new-instance v4, Ljava/io/File;

    invoke-direct {v4, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4}, Ljava/io/File;->exists()Z

    move-result v4

    if-eqz v4, :cond_b0

    .line 568
    new-instance v4, Ljava/io/BufferedReader;

    new-instance v5, Ljava/io/FileReader;

    invoke-direct {v5, v1}, Ljava/io/FileReader;-><init>(Ljava/lang/String;)V

    invoke-direct {v4, v5}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 570
    .local v4, "reader":Ljava/io/BufferedReader;
    invoke-virtual {v4}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v5

    .line 572
    .local v5, "Int_line":Ljava/lang/String;
    if-eqz v5, :cond_ad

    .line 574
    :try_start_a4
    invoke-static {v5}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v6
    :try_end_a8
    .catch Ljava/lang/NumberFormatException; {:try_start_a4 .. :try_end_a8} :catch_aa

    move-wide v2, v6

    .line 579
    goto :goto_ad

    .line 576
    :catch_aa
    move-exception v6

    .line 578
    .local v6, "exc":Ljava/lang/NumberFormatException;
    const-wide/16 v2, 0x0

    .line 582
    .end local v6  # "exc":Ljava/lang/NumberFormatException;
    :cond_ad
    :goto_ad
    invoke-virtual {v4}, Ljava/io/BufferedReader;->close()V

    .line 585
    .end local v4  # "reader":Ljava/io/BufferedReader;
    .end local v5  # "Int_line":Ljava/lang/String;
    :cond_b0
    sget-wide v4, Lcom/fastman92/main_activity_launcher/SettingsGenerated;->apkModifierCompileTimestamp:J

    cmp-long v4, v4, v2

    if-lez v4, :cond_df

    .line 587
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    sget-wide v5, Lcom/fastman92/main_activity_launcher/SettingsGenerated;->apkModifierCompileTimestamp:J

    invoke-static {v5, v6}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, "\n\nfastman92 APK modifier\n\nProject that allows for Android_unprotected directory, which provides an easy access to files that will be used by an application. Solves the problem of restricted access to Android directory.\nHas got many other features as well.\n\nAvailable for many different applications.\n\nLink: https://gtaforums.com/topic/979211-fastman92-apk-modifier/"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 597
    .local v4, "strToWrite":Ljava/lang/String;
    new-instance v5, Ljava/io/BufferedWriter;

    new-instance v6, Ljava/io/FileWriter;

    invoke-direct {v6, v1}, Ljava/io/FileWriter;-><init>(Ljava/lang/String;)V

    invoke-direct {v5, v6}, Ljava/io/BufferedWriter;-><init>(Ljava/io/Writer;)V

    .line 599
    .local v5, "writer":Ljava/io/BufferedWriter;
    invoke-virtual {v5, v4}, Ljava/io/BufferedWriter;->write(Ljava/lang/String;)V

    .line 600
    invoke-virtual {v5}, Ljava/io/BufferedWriter;->close()V

    .line 604
    .end local v1  # "promoPath":Ljava/lang/String;
    .end local v2  # "timestampInAboutFile":J
    .end local v4  # "strToWrite":Ljava/lang/String;
    .end local v5  # "writer":Ljava/io/BufferedWriter;
    :cond_df
    new-instance v1, Ljava/lang/Exception;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Unable to create "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v1

    .line 556
    :cond_fc
    new-instance v1, Ljava/lang/Exception;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Please create the following directory:\n"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "\n\nYou can do it using your file manager. It can\'t be done by this application and you need to do it manually."

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method private static CheckValueDependingOnAndroidUnprotected(Ljava/lang/String;)V
    .registers 6
    .param p0, "key"  # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 666
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "LAUNCHER_"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    .line 667
    sget-object v0, Lcom/fastman92/main_activity_launcher/SettingsLoader;->settingsAll:Ljava/util/HashMap;

    invoke-virtual {v0, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    .line 669
    .local v0, "value":Ljava/lang/String;
    sget-object v2, Lcom/fastman92/main_activity_launcher/SettingsLoader;->context:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_28

    .line 674
    return-void

    .line 670
    :cond_28
    new-instance v2, Ljava/lang/Exception;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " should be "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    sget-object v4, Lcom/fastman92/main_activity_launcher/SettingsLoader;->context:Landroid/content/Context;

    .line 671
    invoke-virtual {v4}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " when not "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, "USE_ANDROID_UNPROTECTED_DIRECTORY.\nCurrent value: "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    sget-object v3, Lcom/fastman92/main_activity_launcher/Settings;->AndroidDATAdirectory:Ljava/lang/String;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v2, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v2
.end method

.method private FinishThisActivity()V
    .registers 6

    .line 211
    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    .line 213
    .local v0, "intent":Landroid/content/Intent;
    sget-object v1, Lcom/fastman92/main_activity_launcher/SettingsLoader;->errorMessage:Ljava/lang/String;

    if-eqz v1, :cond_e

    .line 214
    const-string v2, "errorMessage"

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 216
    :cond_e
    sget-boolean v1, Lcom/fastman92/main_activity_launcher/Settings;->bSettingsLoaded:Z

    if-eqz v1, :cond_5e

    .line 217
    new-instance v1, Ljava/util/TreeMap;

    sget-object v2, Lcom/fastman92/main_activity_launcher/SettingsLoader;->settingsAll:Ljava/util/HashMap;

    invoke-direct {v1, v2}, Ljava/util/TreeMap;-><init>(Ljava/util/Map;)V

    invoke-virtual {v1}, Ljava/util/TreeMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_21
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3d

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    .line 218
    .local v2, "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/String;Ljava/lang/String;>;"
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-virtual {v0, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    goto :goto_21

    .line 221
    .end local v2  # "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/String;Ljava/lang/String;>;"
    :cond_3d
    const/4 v1, 0x0

    invoke-static {p0, v1}, Lcom/fastman92/main_activity_launcher/Settings;->getExternalFilesDir(Landroid/content/Context;Ljava/lang/String;)Ljava/io/File;

    move-result-object v1

    const-string v2, "ExternalFilesDir"

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/io/Serializable;)Landroid/content/Intent;

    .line 222
    invoke-static {p0}, Lcom/fastman92/main_activity_launcher/Settings;->getObbDir(Landroid/content/Context;)Ljava/io/File;

    move-result-object v1

    const-string v2, "ExternalOBBfilesDir"

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/io/Serializable;)Landroid/content/Intent;

    .line 223
    invoke-static {p0}, Lcom/fastman92/main_activity_launcher/Settings;->getAssetPacksDir(Landroid/content/Context;)Ljava/io/File;

    move-result-object v1

    const-string v2, "ExternalAndroidPacksDir"

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/io/Serializable;)Landroid/content/Intent;

    .line 226
    const/4 v1, -0x1

    invoke-virtual {p0, v1, v0}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->setResult(ILandroid/content/Intent;)V

    goto :goto_62

    .line 229
    :cond_5e
    const/4 v1, 0x0

    invoke-virtual {p0, v1, v0}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->setResult(ILandroid/content/Intent;)V

    .line 231
    :goto_62
    invoke-virtual {p0}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->finish()V

    .line 232
    return-void
.end method

.method private static GetPropertyString(Ljava/lang/String;)Ljava/lang/String;
    .registers 2
    .param p0, "key"  # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 458
    const/4 v0, 0x1

    invoke-static {p0, v0}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->GetPropertyString(Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static GetPropertyString(Ljava/lang/String;Z)Ljava/lang/String;
    .registers 8
    .param p0, "key"  # Ljava/lang/String;
    .param p1, "lookIntoSettingsFile"  # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 464
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "LAUNCHER_"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    .line 472
    sget-object v0, Lcom/fastman92/main_activity_launcher/SettingsLoader;->context:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    sget-object v1, Lcom/fastman92/main_activity_launcher/SettingsLoader;->context:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/16 v2, 0x80

    invoke-virtual {v0, v1, v2}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object v0

    .line 473
    .local v0, "ai":Landroid/content/pm/ApplicationInfo;
    iget-object v1, v0, Landroid/content/pm/ApplicationInfo;->metaData:Landroid/os/Bundle;

    .line 475
    .local v1, "bundle":Landroid/os/Bundle;
    invoke-virtual {v1, p0}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 477
    .local v2, "result":Ljava/lang/String;
    if-eqz v2, :cond_44

    .line 481
    if-eqz p1, :cond_3e

    .line 482
    sget-object v3, Lcom/fastman92/main_activity_launcher/SettingsLoader;->settingsStoredInFile:Ljava/util/HashMap;

    invoke-virtual {v3, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    .line 484
    .local v4, "customValue":Ljava/lang/String;
    if-eqz v4, :cond_3b

    .line 485
    move-object v2, v4

    goto :goto_3e

    .line 487
    :cond_3b
    invoke-virtual {v3, p0, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 490
    .end local v4  # "customValue":Ljava/lang/String;
    :cond_3e
    :goto_3e
    sget-object v3, Lcom/fastman92/main_activity_launcher/SettingsLoader;->settingsAll:Ljava/util/HashMap;

    invoke-virtual {v3, p0, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 492
    return-object v2

    .line 478
    :cond_44
    new-instance v3, Ljava/lang/Exception;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Unable to retrieve property "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, " from APK manifest file"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v3
.end method

.method private static GetPropertyYesOrNo(Ljava/lang/String;)Z
    .registers 2
    .param p0, "key"  # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 498
    const/4 v0, 0x1

    invoke-static {p0, v0}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->GetPropertyYesOrNo(Ljava/lang/String;Z)Z

    move-result v0

    return v0
.end method

.method private static GetPropertyYesOrNo(Ljava/lang/String;Z)Z
    .registers 6
    .param p0, "key"  # Ljava/lang/String;
    .param p1, "lookIntoSettingsFile"  # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 504
    invoke-static {p0, p1}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->GetPropertyString(Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v0

    .line 506
    .local v0, "value":Ljava/lang/String;
    const-string v1, "yes"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_e

    .line 507
    const/4 v1, 0x1

    return v1

    .line 508
    :cond_e
    const-string v1, "no"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_18

    .line 509
    const/4 v1, 0x0

    return v1

    .line 511
    :cond_18
    new-instance v1, Ljava/lang/Exception;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", wrong value: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public static InitializeSettings(Landroid/content/Context;Z)V
    .registers 13
    .param p0, "context"  # Landroid/content/Context;
    .param p1, "inActivity"  # Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 258
    const-string v0, "launcher_settings.xml"

    const/4 v1, 0x0

    if-eqz p1, :cond_27

    .line 259
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, v1}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v3

    invoke-virtual {v3}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    sget-object v3, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/fastman92/main_activity_launcher/SettingsLoader;->XMLsettingsFilePath:Ljava/lang/String;

    goto :goto_48

    .line 261
    :cond_27
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v3

    invoke-virtual {v3}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    sget-object v3, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/fastman92/main_activity_launcher/SettingsLoader;->XMLsettingsFilePath:Ljava/lang/String;

    .line 263
    :goto_48
    sput-object v1, Lcom/fastman92/main_activity_launcher/SettingsLoader;->errorMessage:Ljava/lang/String;

    .line 265
    sget-boolean v0, Lcom/fastman92/main_activity_launcher/SettingsLoader;->settingsInitializationAttemptedInActivity:Z

    if-eqz v0, :cond_4f

    .line 267
    return-void

    .line 270
    :cond_4f
    sput-object p0, Lcom/fastman92/main_activity_launcher/SettingsLoader;->context:Landroid/content/Context;

    .line 272
    const/4 v0, 0x1

    if-eqz p1, :cond_56

    .line 273
    sput-boolean v0, Lcom/fastman92/main_activity_launcher/SettingsLoader;->settingsInitializationAttemptedInActivity:Z

    .line 275
    :cond_56
    sget-object v2, Lcom/fastman92/main_activity_launcher/SettingsLoader;->settingsAll:Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->clear()V

    .line 276
    sget-object v3, Lcom/fastman92/main_activity_launcher/SettingsLoader;->settingsStoredInFile:Ljava/util/HashMap;

    invoke-virtual {v3}, Ljava/util/HashMap;->clear()V

    .line 278
    const-string v3, "USE_LAUNCHER_SETTINGS_XML"

    const/4 v4, 0x0

    invoke-static {v3, v4}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->GetPropertyYesOrNo(Ljava/lang/String;Z)Z

    move-result v3

    sput-boolean v3, Lcom/fastman92/main_activity_launcher/SettingsLoader;->useLauncherSettingsXml:Z

    .line 280
    const-string v5, "Configuration file \""

    const-string v6, "fastman92 app launcher"

    if-eqz v3, :cond_bd

    .line 281
    new-instance v3, Ljava/io/File;

    sget-object v7, Lcom/fastman92/main_activity_launcher/SettingsLoader;->XMLsettingsFilePath:Ljava/lang/String;

    invoke-direct {v3, v7}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    move-result v3

    if-eqz v3, :cond_9e

    .line 283
    if-eqz p1, :cond_9a

    .line 284
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    sget-object v5, Lcom/fastman92/main_activity_launcher/SettingsLoader;->XMLsettingsFilePath:Ljava/lang/String;

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v5, "\" exists. Reading it."

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v6, v3}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 286
    :cond_9a
    invoke-static {}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->ReadSettingsFile()V

    goto :goto_db

    .line 287
    :cond_9e
    if-eqz p1, :cond_db

    .line 288
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    sget-object v5, Lcom/fastman92/main_activity_launcher/SettingsLoader;->XMLsettingsFilePath:Ljava/lang/String;

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v5, "\" does not exist. Skipping it."

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v6, v3}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_db

    .line 290
    :cond_bd
    if-eqz p1, :cond_db

    .line 291
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    sget-object v5, Lcom/fastman92/main_activity_launcher/SettingsLoader;->XMLsettingsFilePath:Ljava/lang/String;

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v5, "\" will not be used. Skipping it."

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v6, v3}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 295
    :cond_db
    :goto_db
    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v3

    invoke-virtual {v3}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v3

    sput-object v3, Lcom/fastman92/main_activity_launcher/Functions;->oldExternalStorageDirectory:Ljava/lang/String;

    .line 297
    sget-object v3, Lcom/fastman92/main_activity_launcher/Functions;->oldExternalStorageDirectory:Ljava/lang/String;

    sput-object v3, Lcom/fastman92/main_activity_launcher/Settings;->ExternalStorageDirectory:Ljava/lang/String;

    .line 301
    const-string v3, "/mnt/windows/BstSharedFolder"

    .line 303
    .local v3, "pathToBstSharedMedia":Ljava/lang/String;
    new-instance v5, Ljava/io/File;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, "/use_as_sdcard.txt"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v5, v7}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5}, Ljava/io/File;->exists()Z

    move-result v5

    if-eqz v5, :cond_10b

    .line 304
    sput-object v3, Lcom/fastman92/main_activity_launcher/Settings;->ExternalStorageDirectory:Ljava/lang/String;

    .line 309
    .end local v3  # "pathToBstSharedMedia":Ljava/lang/String;
    :cond_10b
    const-string v3, "ORIGINAL_PACKAGE_NAME"

    invoke-static {v3, v4}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->GetPropertyString(Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v3

    sput-object v3, Lcom/fastman92/main_activity_launcher/Settings;->originalPackageName:Ljava/lang/String;

    .line 311
    const-string v3, "USE_ANDROID_UNPROTECTED_DIRECTORY"

    invoke-static {v3}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->GetPropertyString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 313
    .local v5, "useAndroidUnprotectedDirectory":Ljava/lang/String;
    invoke-static {v3}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->GetPropertyYesOrNo(Ljava/lang/String;)Z

    move-result v3

    const-string v7, "Android_unprotected"

    if-eqz v3, :cond_124

    .line 314
    sput-object v7, Lcom/fastman92/main_activity_launcher/Settings;->AndroidDirectory:Ljava/lang/String;

    goto :goto_128

    .line 316
    :cond_124
    const-string v3, "Android"

    sput-object v3, Lcom/fastman92/main_activity_launcher/Settings;->AndroidDirectory:Ljava/lang/String;

    .line 318
    :goto_128
    const-string v3, "ANDROID_DATA_DIRECTORY"

    invoke-static {v3}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->GetPropertyString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    sput-object v8, Lcom/fastman92/main_activity_launcher/Settings;->AndroidDATAdirectory:Ljava/lang/String;

    .line 319
    const-string v8, "ANDROID_OBB_DIRECTORY"

    invoke-static {v8}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->GetPropertyString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    sput-object v9, Lcom/fastman92/main_activity_launcher/Settings;->AndroidOBBdirectory:Ljava/lang/String;

    .line 321
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "/"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    sget-object v10, Lcom/fastman92/main_activity_launcher/Settings;->AndroidDirectory:Ljava/lang/String;

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, "/obb/"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    sput-object v9, Lcom/fastman92/main_activity_launcher/Settings;->OBB_PATH_PREFIX:Ljava/lang/String;

    .line 323
    sget-object v9, Lcom/fastman92/main_activity_launcher/Settings;->AndroidDirectory:Ljava/lang/String;

    invoke-virtual {v9, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_163

    .line 325
    invoke-static {v3}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->CheckValueDependingOnAndroidUnprotected(Ljava/lang/String;)V

    .line 326
    invoke-static {v8}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->CheckValueDependingOnAndroidUnprotected(Ljava/lang/String;)V

    .line 336
    :cond_163
    const-string v3, "CHECK_FOR_MULTIPLE_DIRS"

    invoke-static {v3, v4}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->GetPropertyYesOrNo(Ljava/lang/String;Z)Z

    move-result v3

    sput-boolean v3, Lcom/fastman92/main_activity_launcher/SettingsLoader;->bCheckForMultipleDirs:Z

    .line 338
    if-eqz p1, :cond_18d

    .line 341
    nop

    .line 342
    invoke-static {p0, v1}, Lcom/fastman92/main_activity_launcher/Settings;->getExternalFilesDirs(Landroid/content/Context;Ljava/lang/String;)[Ljava/io/File;

    move-result-object v1

    .line 341
    invoke-static {v1, v0, v0}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->CheckIfDirectoriesExist([Ljava/io/File;ZZ)V

    .line 347
    nop

    .line 348
    invoke-static {p0}, Lcom/fastman92/main_activity_launcher/Settings;->getObbDirs(Landroid/content/Context;)[Ljava/io/File;

    move-result-object v1

    .line 347
    invoke-static {v1, v0, v4}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->CheckIfDirectoriesExist([Ljava/io/File;ZZ)V

    .line 353
    const-string v1, "ASSETPACKS_USED"

    invoke-static {v1, v4}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->GetPropertyYesOrNo(Ljava/lang/String;Z)Z

    move-result v1

    if-eqz v1, :cond_18d

    .line 354
    nop

    .line 355
    invoke-static {p0}, Lcom/fastman92/main_activity_launcher/Settings;->getAssetPacksDir(Landroid/content/Context;)Ljava/io/File;

    move-result-object v1

    .line 354
    invoke-static {v1, v4, v4}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->CheckIfDirectoryExists(Ljava/io/File;ZZ)V

    .line 363
    :cond_18d
    const-string v1, "SHOW_MESSAGE_BOX_ON_APPLICATION_STARTUP"

    invoke-static {v1}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->GetPropertyYesOrNo(Ljava/lang/String;)Z

    move-result v1

    sput-boolean v1, Lcom/fastman92/main_activity_launcher/Settings;->showMessageBoxBeforeStartingApplication:Z

    .line 367
    if-eqz p1, :cond_1f4

    .line 369
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 371
    .local v1, "settingsStr":Ljava/lang/StringBuilder;
    const/4 v3, 0x0

    .line 373
    .local v3, "ID":I
    new-instance v4, Ljava/util/TreeMap;

    invoke-direct {v4, v2}, Ljava/util/TreeMap;-><init>(Ljava/util/Map;)V

    invoke-virtual {v4}, Ljava/util/TreeMap;->entrySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_1aa
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_1d8

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/Map$Entry;

    .line 375
    .local v4, "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/String;Ljava/lang/String;>;"
    if-eqz v3, :cond_1bd

    .line 376
    const-string v7, ", "

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 378
    :cond_1bd
    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 379
    const-string v7, " = "

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 380
    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 382
    nop

    .end local v4  # "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/String;Ljava/lang/String;>;"
    add-int/lit8 v3, v3, 0x1

    .line 383
    goto :goto_1aa

    .line 385
    :cond_1d8
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Settings ("

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, ")"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v6, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 403
    .end local v1  # "settingsStr":Ljava/lang/StringBuilder;
    .end local v3  # "ID":I
    :cond_1f4
    sput-boolean v0, Lcom/fastman92/main_activity_launcher/Settings;->bSettingsLoaded:Z

    .line 404
    return-void
.end method

.method private static InitializeSettingsInActivity(Landroid/content/Context;)V
    .registers 9
    .param p0, "context"  # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 408
    const/4 v0, 0x1

    invoke-static {p0, v0}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->InitializeSettings(Landroid/content/Context;Z)V

    .line 410
    sget-boolean v0, Lcom/fastman92/main_activity_launcher/SettingsLoader;->useLauncherSettingsXml:Z

    if-eqz v0, :cond_38

    new-instance v0, Ljava/io/File;

    sget-object v1, Lcom/fastman92/main_activity_launcher/SettingsLoader;->XMLsettingsFilePath:Ljava/lang/String;

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v0

    if-nez v0, :cond_38

    .line 411
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Configuration file \""

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    sget-object v1, Lcom/fastman92/main_activity_launcher/SettingsLoader;->XMLsettingsFilePath:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\" does not exist. Writing it."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "fastman92 app launcher"

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 413
    invoke-static {}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->WriteSettingsFile()V

    .line 416
    :cond_38
    sget-boolean v0, Lcom/fastman92/main_activity_launcher/SettingsLoader;->useLauncherSettingsXml:Z

    if-eqz v0, :cond_8b

    .line 420
    new-instance v0, Ljava/io/FileInputStream;

    sget-object v1, Lcom/fastman92/main_activity_launcher/SettingsLoader;->XMLsettingsFilePath:Ljava/lang/String;

    invoke-direct {v0, v1}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    .line 423
    invoke-virtual {v0}, Ljava/io/FileInputStream;->getChannel()Ljava/nio/channels/FileChannel;

    move-result-object v0

    .line 424
    .local v0, "src":Ljava/nio/channels/FileChannel;
    new-instance v1, Ljava/io/FileOutputStream;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 426
    invoke-virtual {p0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v3

    invoke-virtual {v3}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    sget-object v3, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "launcher_settings.xml"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/io/FileOutputStream;-><init>(Ljava/lang/String;)V

    .line 427
    invoke-virtual {v1}, Ljava/io/FileOutputStream;->getChannel()Ljava/nio/channels/FileChannel;

    move-result-object v1

    .line 434
    .local v1, "dest":Ljava/nio/channels/FileChannel;
    const-wide/16 v4, 0x0

    :try_start_73
    invoke-virtual {v0}, Ljava/nio/channels/FileChannel;->size()J

    move-result-wide v6

    move-object v2, v1

    move-object v3, v0

    invoke-virtual/range {v2 .. v7}, Ljava/nio/channels/FileChannel;->transferFrom(Ljava/nio/channels/ReadableByteChannel;JJ)J
    :try_end_7c
    .catchall {:try_start_73 .. :try_end_7c} :catchall_83

    .line 447
    invoke-virtual {v0}, Ljava/nio/channels/FileChannel;->close()V

    .line 450
    invoke-virtual {v1}, Ljava/nio/channels/FileChannel;->close()V

    .line 451
    goto :goto_8b

    .line 447
    :catchall_83
    move-exception v2

    invoke-virtual {v0}, Ljava/nio/channels/FileChannel;->close()V

    .line 450
    invoke-virtual {v1}, Ljava/nio/channels/FileChannel;->close()V

    .line 451
    throw v2

    .line 453
    .end local v0  # "src":Ljava/nio/channels/FileChannel;
    .end local v1  # "dest":Ljava/nio/channels/FileChannel;
    :cond_8b
    :goto_8b
    return-void
.end method

.method private OnSettingsLoaded()V
    .registers 3

    .line 235
    sget-boolean v0, Lcom/fastman92/main_activity_launcher/Settings;->showMessageBoxBeforeStartingApplication:Z

    if-eqz v0, :cond_f

    .line 236
    new-instance v0, Lcom/fastman92/main_activity_launcher/SettingsLoader$$ExternalSyntheticLambda1;

    invoke-direct {v0, p0}, Lcom/fastman92/main_activity_launcher/SettingsLoader$$ExternalSyntheticLambda1;-><init>(Lcom/fastman92/main_activity_launcher/SettingsLoader;)V

    const-string v1, "Message before an application gets started."

    invoke-static {p0, v1, v0}, Lcom/fastman92/main_activity_launcher/Functions;->ShowMessageBox(Landroid/app/Activity;Ljava/lang/String;Landroid/content/DialogInterface$OnCancelListener;)V

    goto :goto_12

    .line 244
    :cond_f
    invoke-direct {p0}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->FinishThisActivity()V

    .line 245
    :goto_12
    return-void
.end method

.method private static ReadSettingsFile()V
    .registers 10
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 609
    invoke-static {}, Ljavax/xml/parsers/DocumentBuilderFactory;->newInstance()Ljavax/xml/parsers/DocumentBuilderFactory;

    move-result-object v0

    .line 614
    .local v0, "docFactory":Ljavax/xml/parsers/DocumentBuilderFactory;
    :try_start_4
    invoke-virtual {v0}, Ljavax/xml/parsers/DocumentBuilderFactory;->newDocumentBuilder()Ljavax/xml/parsers/DocumentBuilder;

    move-result-object v1

    .line 615
    .local v1, "docBuilder":Ljavax/xml/parsers/DocumentBuilder;
    new-instance v2, Ljava/io/File;

    sget-object v3, Lcom/fastman92/main_activity_launcher/SettingsLoader;->XMLsettingsFilePath:Ljava/lang/String;

    invoke-direct {v2, v3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Ljavax/xml/parsers/DocumentBuilder;->parse(Ljava/io/File;)Lorg/w3c/dom/Document;

    move-result-object v2

    .line 619
    .local v2, "doc":Lorg/w3c/dom/Document;
    invoke-interface {v2}, Lorg/w3c/dom/Document;->getDocumentElement()Lorg/w3c/dom/Element;

    move-result-object v3

    invoke-interface {v3}, Lorg/w3c/dom/Element;->normalize()V

    .line 621
    const-string v3, "CONFIGURATION"

    invoke-interface {v2, v3}, Lorg/w3c/dom/Document;->getElementsByTagName(Ljava/lang/String;)Lorg/w3c/dom/NodeList;

    move-result-object v3

    const/4 v4, 0x0

    invoke-interface {v3, v4}, Lorg/w3c/dom/NodeList;->item(I)Lorg/w3c/dom/Node;

    move-result-object v3

    .line 622
    .local v3, "CONFIGURATION":Lorg/w3c/dom/Node;
    invoke-interface {v3}, Lorg/w3c/dom/Node;->getChildNodes()Lorg/w3c/dom/NodeList;

    move-result-object v4

    .line 624
    .local v4, "list":Lorg/w3c/dom/NodeList;
    const/4 v5, 0x0

    .local v5, "temp":I
    :goto_2a
    invoke-interface {v4}, Lorg/w3c/dom/NodeList;->getLength()I

    move-result v6

    if-ge v5, v6, :cond_4b

    .line 625
    invoke-interface {v4, v5}, Lorg/w3c/dom/NodeList;->item(I)Lorg/w3c/dom/Node;

    move-result-object v6

    .line 627
    .local v6, "node":Lorg/w3c/dom/Node;
    invoke-interface {v6}, Lorg/w3c/dom/Node;->getNodeType()S

    move-result v7

    const/4 v8, 0x1

    if-ne v7, v8, :cond_48

    .line 629
    invoke-interface {v6}, Lorg/w3c/dom/Node;->getNodeName()Ljava/lang/String;

    move-result-object v7

    .line 630
    .local v7, "key":Ljava/lang/String;
    invoke-interface {v6}, Lorg/w3c/dom/Node;->getTextContent()Ljava/lang/String;

    move-result-object v8

    .line 632
    .local v8, "value":Ljava/lang/String;
    sget-object v9, Lcom/fastman92/main_activity_launcher/SettingsLoader;->settingsStoredInFile:Ljava/util/HashMap;

    invoke-virtual {v9, v7, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_48
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_48} :catch_4d

    .line 624
    .end local v6  # "node":Lorg/w3c/dom/Node;
    .end local v7  # "key":Ljava/lang/String;
    .end local v8  # "value":Ljava/lang/String;
    :cond_48
    add-int/lit8 v5, v5, 0x1

    goto :goto_2a

    .line 638
    .end local v1  # "docBuilder":Ljavax/xml/parsers/DocumentBuilder;
    .end local v2  # "doc":Lorg/w3c/dom/Document;
    .end local v3  # "CONFIGURATION":Lorg/w3c/dom/Node;
    .end local v4  # "list":Lorg/w3c/dom/NodeList;
    .end local v5  # "temp":I
    :cond_4b
    nop

    .line 639
    return-void

    .line 636
    :catch_4d
    move-exception v1

    .line 637
    .local v1, "e":Ljava/lang/Exception;
    new-instance v2, Ljava/lang/Exception;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Error while reading "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    sget-object v4, Lcom/fastman92/main_activity_launcher/SettingsLoader;->XMLsettingsFilePath:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v2
.end method

.method static SetErrorMessage(Ljava/lang/String;)V
    .registers 1
    .param p0, "msg"  # Ljava/lang/String;

    .line 250
    sput-object p0, Lcom/fastman92/main_activity_launcher/SettingsLoader;->errorMessage:Ljava/lang/String;

    .line 251
    return-void
.end method

.method private static WriteSettingsFile()V
    .registers 10
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 643
    invoke-static {}, Ljavax/xml/parsers/DocumentBuilderFactory;->newInstance()Ljavax/xml/parsers/DocumentBuilderFactory;

    move-result-object v0

    .line 644
    .local v0, "docFactory":Ljavax/xml/parsers/DocumentBuilderFactory;
    invoke-virtual {v0}, Ljavax/xml/parsers/DocumentBuilderFactory;->newDocumentBuilder()Ljavax/xml/parsers/DocumentBuilder;

    move-result-object v1

    .line 645
    .local v1, "docBuilder":Ljavax/xml/parsers/DocumentBuilder;
    invoke-virtual {v1}, Ljavax/xml/parsers/DocumentBuilder;->newDocument()Lorg/w3c/dom/Document;

    move-result-object v2

    .line 646
    .local v2, "doc":Lorg/w3c/dom/Document;
    const-string v3, "CONFIGURATION"

    invoke-interface {v2, v3}, Lorg/w3c/dom/Document;->createElement(Ljava/lang/String;)Lorg/w3c/dom/Element;

    move-result-object v3

    .line 647
    .local v3, "rootElement":Lorg/w3c/dom/Element;
    invoke-interface {v2, v3}, Lorg/w3c/dom/Document;->appendChild(Lorg/w3c/dom/Node;)Lorg/w3c/dom/Node;

    .line 649
    new-instance v4, Ljava/util/TreeMap;

    sget-object v5, Lcom/fastman92/main_activity_launcher/SettingsLoader;->settingsStoredInFile:Ljava/util/HashMap;

    invoke-direct {v4, v5}, Ljava/util/TreeMap;-><init>(Ljava/util/Map;)V

    invoke-virtual {v4}, Ljava/util/TreeMap;->entrySet()Ljava/util/Set;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_24
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_4b

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/Map$Entry;

    .line 650
    .local v5, "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/String;Ljava/lang/String;>;"
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    invoke-interface {v2, v6}, Lorg/w3c/dom/Document;->createElement(Ljava/lang/String;)Lorg/w3c/dom/Element;

    move-result-object v6

    .line 651
    .local v6, "element":Lorg/w3c/dom/Element;
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    invoke-interface {v2, v7}, Lorg/w3c/dom/Document;->createTextNode(Ljava/lang/String;)Lorg/w3c/dom/Text;

    move-result-object v7

    invoke-interface {v6, v7}, Lorg/w3c/dom/Element;->appendChild(Lorg/w3c/dom/Node;)Lorg/w3c/dom/Node;

    .line 652
    invoke-interface {v3, v6}, Lorg/w3c/dom/Element;->appendChild(Lorg/w3c/dom/Node;)Lorg/w3c/dom/Node;

    .line 653
    .end local v5  # "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/String;Ljava/lang/String;>;"
    .end local v6  # "element":Lorg/w3c/dom/Element;
    goto :goto_24

    .line 655
    :cond_4b
    invoke-static {}, Ljavax/xml/transform/TransformerFactory;->newInstance()Ljavax/xml/transform/TransformerFactory;

    move-result-object v4

    .line 656
    .local v4, "transformerFactory":Ljavax/xml/transform/TransformerFactory;
    invoke-virtual {v4}, Ljavax/xml/transform/TransformerFactory;->newTransformer()Ljavax/xml/transform/Transformer;

    move-result-object v5

    .line 657
    .local v5, "transformer":Ljavax/xml/transform/Transformer;
    const-string v6, "indent"

    const-string v7, "yes"

    invoke-virtual {v5, v6, v7}, Ljavax/xml/transform/Transformer;->setOutputProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 658
    const-string v6, "{http://xml.apache.org/xslt}indent-amount"

    const-string v7, "4"

    invoke-virtual {v5, v6, v7}, Ljavax/xml/transform/Transformer;->setOutputProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 659
    new-instance v6, Ljavax/xml/transform/dom/DOMSource;

    invoke-direct {v6, v2}, Ljavax/xml/transform/dom/DOMSource;-><init>(Lorg/w3c/dom/Node;)V

    .line 660
    .local v6, "source":Ljavax/xml/transform/dom/DOMSource;
    new-instance v7, Ljavax/xml/transform/stream/StreamResult;

    new-instance v8, Ljava/io/File;

    sget-object v9, Lcom/fastman92/main_activity_launcher/SettingsLoader;->XMLsettingsFilePath:Ljava/lang/String;

    invoke-direct {v8, v9}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-direct {v7, v8}, Ljavax/xml/transform/stream/StreamResult;-><init>(Ljava/io/File;)V

    .line 661
    .local v7, "result":Ljavax/xml/transform/stream/StreamResult;
    invoke-virtual {v5, v6, v7}, Ljavax/xml/transform/Transformer;->transform(Ljavax/xml/transform/Source;Ljavax/xml/transform/Result;)V

    .line 662
    return-void
.end method

.method static synthetic lambda$requestPermissions$0(Lcom/fastman92/main_activity_launcher/SettingsLoader$OnRequestPermissions;Landroid/content/DialogInterface;)V
    .registers 2
    .param p0, "var"  # Lcom/fastman92/main_activity_launcher/SettingsLoader$OnRequestPermissions;
    .param p1, "dialogInterface"  # Landroid/content/DialogInterface;

    .line 73
    invoke-interface {p0}, Lcom/fastman92/main_activity_launcher/SettingsLoader$OnRequestPermissions;->onRequestPermissions()V

    return-void
.end method

.method private requestPermissions(Lcom/fastman92/main_activity_launcher/SettingsLoader$OnRequestPermissions;)V
    .registers 4
    .param p1, "var"  # Lcom/fastman92/main_activity_launcher/SettingsLoader$OnRequestPermissions;

    .line 71
    new-instance v0, Lcom/fastman92/main_activity_launcher/SettingsLoader$$ExternalSyntheticLambda0;

    invoke-direct {v0, p1}, Lcom/fastman92/main_activity_launcher/SettingsLoader$$ExternalSyntheticLambda0;-><init>(Lcom/fastman92/main_activity_launcher/SettingsLoader$OnRequestPermissions;)V

    const-string v1, "Permission to access files is needed. Please accept."

    invoke-static {p0, v1, v0}, Lcom/fastman92/main_activity_launcher/Functions;->ShowMessageBox(Landroid/app/Activity;Ljava/lang/String;Landroid/content/DialogInterface$OnCancelListener;)V

    .line 75
    return-void
.end method

.method private requestPermissionsCompat([Ljava/lang/String;I)V
    .registers 8
    .param p1, "permissions"  # [Ljava/lang/String;
    .param p2, "requestCode"  # I

    .line 172
    move-object v0, p0

    .line 174
    .local v0, "activity":Lcom/fastman92/main_activity_launcher/SettingsLoader;
    array-length v1, p1

    const/4 v2, 0x0

    :goto_3
    if-ge v2, v1, :cond_33

    aget-object v3, p1, v2

    .line 175
    .local v3, "permission":Ljava/lang/String;
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_10

    .line 174
    .end local v3  # "permission":Ljava/lang/String;
    add-int/lit8 v2, v2, 0x1

    goto :goto_3

    .line 176
    .restart local v3  # "permission":Ljava/lang/String;
    :cond_10
    new-instance v1, Ljava/lang/IllegalArgumentException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Permission request for permissions "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 177
    invoke-static {p1}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " must not contain null or empty values"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 181
    .end local v3  # "permission":Ljava/lang/String;
    :cond_33
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x17

    if-lt v1, v2, :cond_3d

    .line 184
    invoke-virtual {v0, p1, p2}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->requestPermissions([Ljava/lang/String;I)V

    goto :goto_4e

    .line 186
    :cond_3d
    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 187
    .local v1, "handler":Landroid/os/Handler;
    new-instance v2, Lcom/fastman92/main_activity_launcher/SettingsLoader$1;

    invoke-direct {v2, p0, p1, v0, p2}, Lcom/fastman92/main_activity_launcher/SettingsLoader$1;-><init>(Lcom/fastman92/main_activity_launcher/SettingsLoader;[Ljava/lang/String;Lcom/fastman92/main_activity_launcher/SettingsLoader;I)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 206
    .end local v1  # "handler":Landroid/os/Handler;
    :goto_4e
    return-void
.end method


# virtual methods
.method synthetic lambda$OnSettingsLoaded$3$com-fastman92-main_activity_launcher-SettingsLoader(Landroid/content/DialogInterface;)V
    .registers 2
    .param p1, "dialogInterface"  # Landroid/content/DialogInterface;

    .line 239
    invoke-direct {p0}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->FinishThisActivity()V

    .line 240
    return-void
.end method

.method synthetic lambda$onCreate$1$com-fastman92-main_activity_launcher-SettingsLoader()V
    .registers 6

    .line 90
    const/16 v0, 0x65

    :try_start_2
    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "package:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    .line 92
    invoke-virtual {p0}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 94
    .local v1, "intent":Landroid/content/Intent;
    invoke-virtual {p0, v1, v0}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->startActivityForResult(Landroid/content/Intent;I)V
    :try_end_27
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_27} :catch_28

    .line 100
    .end local v1  # "intent":Landroid/content/Intent;
    goto :goto_36

    .line 96
    :catch_28
    move-exception v1

    .line 97
    .local v1, "e":Ljava/lang/Exception;
    new-instance v2, Landroid/content/Intent;

    invoke-direct {v2}, Landroid/content/Intent;-><init>()V

    .line 98
    .local v2, "intent":Landroid/content/Intent;
    const-string v3, "android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION"

    invoke-virtual {v2, v3}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 99
    invoke-virtual {p0, v2, v0}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->startActivityForResult(Landroid/content/Intent;I)V

    .line 101
    .end local v1  # "e":Ljava/lang/Exception;
    .end local v2  # "intent":Landroid/content/Intent;
    :goto_36
    return-void
.end method

.method synthetic lambda$onCreate$2$com-fastman92-main_activity_launcher-SettingsLoader()V
    .registers 3

    .line 112
    const-string v0, "android.permission.WRITE_EXTERNAL_STORAGE"

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x64

    invoke-direct {p0, v0, v1}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->requestPermissionsCompat([Ljava/lang/String;I)V

    .line 113
    return-void
.end method

.method protected onActivityResult(IILandroid/content/Intent;)V
    .registers 6
    .param p1, "requestCode"  # I
    .param p2, "resultCode"  # I
    .param p3, "data"  # Landroid/content/Intent;

    .line 131
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    .line 133
    const/16 v0, 0x65

    if-ne p1, v0, :cond_28

    .line 136
    :try_start_7
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1e

    if-lt v0, v1, :cond_1c

    .line 137
    invoke-static {}, Landroid/os/Environment;->isExternalStorageManager()Z

    move-result v0

    if-eqz v0, :cond_14

    goto :goto_1c

    .line 138
    :cond_14
    new-instance v0, Ljava/lang/Exception;

    const-string v1, "Unable to obtain MANAGE_EXTERNAL_STORAGE permission."

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .end local p1  # "requestCode":I
    .end local p2  # "resultCode":I
    .end local p3  # "data":Landroid/content/Intent;
    throw v0

    .line 140
    .restart local p1  # "requestCode":I
    .restart local p2  # "resultCode":I
    .restart local p3  # "data":Landroid/content/Intent;
    :cond_1c
    :goto_1c
    invoke-static {p0}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->InitializeSettingsInActivity(Landroid/content/Context;)V
    :try_end_1f
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_1f} :catch_20

    .line 144
    goto :goto_28

    .line 142
    :catch_20
    move-exception v0

    .line 143
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->SetErrorMessage(Ljava/lang/String;)V

    .line 147
    .end local v0  # "e":Ljava/lang/Exception;
    :cond_28
    :goto_28
    invoke-direct {p0}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->OnSettingsLoaded()V

    .line 148
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .registers 6
    .param p1, "savedInstanceState"  # Landroid/os/Bundle;

    .line 79
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 81
    const/4 v0, 0x0

    .line 83
    .local v0, "bNeedToWaitForPermissions":Z
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1e

    if-lt v1, v2, :cond_22

    .line 84
    invoke-virtual {p0}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v1

    iget v1, v1, Landroid/content/pm/ApplicationInfo;->targetSdkVersion:I

    if-lt v1, v2, :cond_22

    .line 85
    invoke-static {}, Landroid/os/Environment;->isExternalStorageManager()Z

    move-result v1

    if-nez v1, :cond_3b

    .line 86
    const/4 v0, 0x1

    .line 88
    new-instance v1, Lcom/fastman92/main_activity_launcher/SettingsLoader$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0}, Lcom/fastman92/main_activity_launcher/SettingsLoader$$ExternalSyntheticLambda2;-><init>(Lcom/fastman92/main_activity_launcher/SettingsLoader;)V

    invoke-direct {p0, v1}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->requestPermissions(Lcom/fastman92/main_activity_launcher/SettingsLoader$OnRequestPermissions;)V

    goto :goto_3b

    .line 107
    :cond_22
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v1

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v2

    const-string v3, "android.permission.WRITE_EXTERNAL_STORAGE"

    invoke-virtual {p0, v3, v1, v2}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->checkPermission(Ljava/lang/String;II)I

    move-result v1

    if-eqz v1, :cond_3b

    .line 109
    const/4 v0, 0x1

    .line 111
    new-instance v1, Lcom/fastman92/main_activity_launcher/SettingsLoader$$ExternalSyntheticLambda3;

    invoke-direct {v1, p0}, Lcom/fastman92/main_activity_launcher/SettingsLoader$$ExternalSyntheticLambda3;-><init>(Lcom/fastman92/main_activity_launcher/SettingsLoader;)V

    invoke-direct {p0, v1}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->requestPermissions(Lcom/fastman92/main_activity_launcher/SettingsLoader$OnRequestPermissions;)V

    .line 117
    :cond_3b
    :goto_3b
    if-nez v0, :cond_4c

    .line 120
    :try_start_3d
    invoke-static {p0}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->InitializeSettingsInActivity(Landroid/content/Context;)V
    :try_end_40
    .catch Ljava/lang/Exception; {:try_start_3d .. :try_end_40} :catch_41

    .line 123
    goto :goto_49

    .line 121
    :catch_41
    move-exception v1

    .line 122
    .local v1, "e":Ljava/lang/Exception;
    invoke-virtual {v1}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->SetErrorMessage(Ljava/lang/String;)V

    .line 125
    .end local v1  # "e":Ljava/lang/Exception;
    :goto_49
    invoke-direct {p0}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->OnSettingsLoaded()V

    .line 127
    :cond_4c
    return-void
.end method

.method public onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .registers 6
    .param p1, "requestCode"  # I
    .param p2, "permissions"  # [Ljava/lang/String;
    .param p3, "grantResults"  # [I

    .line 153
    const/16 v0, 0x64

    if-ne p1, v0, :cond_20

    .line 155
    :try_start_4
    array-length v0, p3

    if-lez v0, :cond_10

    const/4 v0, 0x0

    aget v0, p3, v0

    if-nez v0, :cond_10

    .line 160
    invoke-static {p0}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->InitializeSettingsInActivity(Landroid/content/Context;)V

    .line 164
    goto :goto_20

    .line 158
    :cond_10
    new-instance v0, Ljava/lang/Exception;

    const-string v1, "Unable to obtain WRITE_EXTERNAL_STORAGE permission."

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .end local p1  # "requestCode":I
    .end local p2  # "permissions":[Ljava/lang/String;
    .end local p3  # "grantResults":[I
    throw v0
    :try_end_18
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_18} :catch_18

    .line 162
    .restart local p1  # "requestCode":I
    .restart local p2  # "permissions":[Ljava/lang/String;
    .restart local p3  # "grantResults":[I
    :catch_18
    move-exception v0

    .line 163
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->SetErrorMessage(Ljava/lang/String;)V

    .line 167
    .end local v0  # "e":Ljava/lang/Exception;
    :cond_20
    :goto_20
    invoke-direct {p0}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->OnSettingsLoaded()V

    .line 168
    return-void
.end method
