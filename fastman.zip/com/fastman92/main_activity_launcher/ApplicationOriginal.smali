.class public Lcom/fastman92/main_activity_launcher/ApplicationOriginal;
.super Landroid/app/Application;
.source "ApplicationOriginal.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 3
    invoke-direct {p0}, Landroid/app/Application;-><init>()V

    return-void
.end method
