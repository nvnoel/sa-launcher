.class public final synthetic Lcom/fastman92/main_activity_launcher/SettingsLoader$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnCancelListener;


# instance fields
.field public final synthetic f$0:Lcom/fastman92/main_activity_launcher/SettingsLoader;


# direct methods
.method public synthetic constructor <init>(Lcom/fastman92/main_activity_launcher/SettingsLoader;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fastman92/main_activity_launcher/SettingsLoader$$ExternalSyntheticLambda1;->f$0:Lcom/fastman92/main_activity_launcher/SettingsLoader;

    return-void
.end method


# virtual methods
.method public final onCancel(Landroid/content/DialogInterface;)V
    .registers 3

    iget-object v0, p0, Lcom/fastman92/main_activity_launcher/SettingsLoader$$ExternalSyntheticLambda1;->f$0:Lcom/fastman92/main_activity_launcher/SettingsLoader;

    invoke-virtual {v0, p1}, Lcom/fastman92/main_activity_launcher/SettingsLoader;->lambda$OnSettingsLoaded$3$com-fastman92-main_activity_launcher-SettingsLoader(Landroid/content/DialogInterface;)V

    return-void
.end method
