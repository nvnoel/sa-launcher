.class public final Lcom/rockstargames/gtasa/R$color;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/rockstargames/gtasa/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "color"
.end annotation


# static fields
.field public static final black:I = 0x7f070017

.field public static final common_action_bar_splitter:I = 0x7f070009

.field public static final common_signin_btn_dark_text_default:I = 0x7f070000

.field public static final common_signin_btn_dark_text_disabled:I = 0x7f070002

.field public static final common_signin_btn_dark_text_focused:I = 0x7f070003

.field public static final common_signin_btn_dark_text_pressed:I = 0x7f070001

.field public static final common_signin_btn_default_background:I = 0x7f070008

.field public static final common_signin_btn_light_text_default:I = 0x7f070004

.field public static final common_signin_btn_light_text_disabled:I = 0x7f070006

.field public static final common_signin_btn_light_text_focused:I = 0x7f070007

.field public static final common_signin_btn_light_text_pressed:I = 0x7f070005

.field public static final common_signin_btn_text_dark:I = 0x7f070018

.field public static final common_signin_btn_text_light:I = 0x7f070019

.field public static final wallet_bright_foreground_disabled_holo_light:I = 0x7f07000f

.field public static final wallet_bright_foreground_holo_dark:I = 0x7f07000a

.field public static final wallet_bright_foreground_holo_light:I = 0x7f070010

.field public static final wallet_dim_foreground_disabled_holo_dark:I = 0x7f07000c

.field public static final wallet_dim_foreground_holo_dark:I = 0x7f07000b

.field public static final wallet_dim_foreground_inverse_disabled_holo_dark:I = 0x7f07000e

.field public static final wallet_dim_foreground_inverse_holo_dark:I = 0x7f07000d

.field public static final wallet_highlighted_text_holo_dark:I = 0x7f070014

.field public static final wallet_highlighted_text_holo_light:I = 0x7f070013

.field public static final wallet_hint_foreground_holo_dark:I = 0x7f070012

.field public static final wallet_hint_foreground_holo_light:I = 0x7f070011

.field public static final wallet_holo_blue_light:I = 0x7f070015

.field public static final wallet_link_text_light:I = 0x7f070016

.field public static final wallet_primary_text_holo_light:I = 0x7f07001a

.field public static final wallet_secondary_text_holo_dark:I = 0x7f07001b


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 329
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
